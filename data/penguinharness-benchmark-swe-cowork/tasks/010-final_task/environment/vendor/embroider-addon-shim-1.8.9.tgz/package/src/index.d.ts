/// <reference types="broccoli-funnel" />
import { AddonInstance } from '@embroider/shared-internals';
export interface ShimOptions {
    disabled?: (options: any) => boolean;
}
export declare function addonV1Shim(directory: string, options?: ShimOptions): {
    name: string;
    included(this: AddonInstance & {
        registerV2Addon(name: string, dir: string): void;
    }, ...args: unknown[]): void;
    treeForApp(this: AddonInstance): import("broccoli-funnel").Funnel | undefined;
    treeForAddon(): undefined;
    treeForPublic(this: AddonInstance): import("broccoli-funnel").Funnel | undefined;
    cacheKeyForTree(this: AddonInstance, treeType: string): string;
    isDevelopingAddon(this: AddonInstance): boolean;
    registerV2Addon(this: AddonInstance, name: string, root: string): void;
};
