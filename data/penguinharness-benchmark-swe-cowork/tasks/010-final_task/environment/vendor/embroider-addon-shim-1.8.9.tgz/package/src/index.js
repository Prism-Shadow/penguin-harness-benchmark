"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addonV1Shim = void 0;
const shared_internals_1 = require("@embroider/shared-internals");
const broccoli_funnel_1 = __importDefault(require("broccoli-funnel"));
const common_ancestor_path_1 = __importDefault(require("common-ancestor-path"));
const fs_1 = require("fs");
const path_1 = require("path");
const semver_1 = require("semver");
function addonMeta(pkgJSON) {
    let meta = pkgJSON['ember-addon'];
    if ((meta === null || meta === void 0 ? void 0 : meta.version) !== 2 || (meta === null || meta === void 0 ? void 0 : meta.type) !== 'addon') {
        throw new Error(`did not find valid v2 addon metadata in ${pkgJSON.name}`);
    }
    return meta;
}
function addonV1Shim(directory, options = {}) {
    let pkg = JSON.parse((0, fs_1.readFileSync)((0, path_1.resolve)(directory, './package.json'), 'utf8'));
    let meta = addonMeta(pkg);
    let disabled = false;
    function treeFor(addonInstance, resourceMap, 
    // default expectation is for resourceMap to map from interior to exterior, swap if needed
    swapInteriorExterior = false) {
        var _a;
        const absoluteInteriorPaths = Object[swapInteriorExterior ? 'values' : 'keys'](resourceMap).map((internalPath) => (0, path_1.join)(directory, internalPath));
        if (absoluteInteriorPaths.length === 0) {
            return;
        }
        const ancestorPath = (_a = (0, common_ancestor_path_1.default)(...absoluteInteriorPaths.map(path_1.dirname))) !== null && _a !== void 0 ? _a : directory;
        const ancestorPathRel = (0, path_1.relative)(directory, ancestorPath);
        const ancestorTree = addonInstance.treeGenerator(ancestorPath);
        const relativeInteriorPaths = absoluteInteriorPaths.map((absPath) => (0, path_1.relative)(ancestorPath, absPath));
        return (0, broccoli_funnel_1.default)(ancestorTree, {
            files: relativeInteriorPaths,
            getDestinationPath(relativePath) {
                for (let [a, b] of Object.entries(resourceMap)) {
                    const interiorName = swapInteriorExterior ? b : a;
                    const exteriorName = swapInteriorExterior ? a : b;
                    if ((0, path_1.join)(ancestorPathRel, relativePath) === (0, path_1.normalize)(interiorName)) {
                        return exteriorName;
                    }
                }
                throw new Error(`bug in addonV1Shim, no match for ${relativePath} in ${JSON.stringify(resourceMap)}`);
            },
        });
    }
    return {
        name: pkg.name,
        included(...args) {
            let parentOptions;
            if ((0, shared_internals_1.isDeepAddonInstance)(this)) {
                parentOptions = this.parent.options;
            }
            else {
                parentOptions = this.app.options;
            }
            this.registerV2Addon(this.name, directory);
            if (options.disabled) {
                disabled = options.disabled(parentOptions);
            }
            // this is at the end so we can find our own autoImportInstance before any
            // deeper v2 addons ask us to forward registrations upward to it
            this._super.included.apply(this, args);
        },
        treeForApp() {
            if (disabled) {
                return undefined;
            }
            let maybeAppJS = meta['app-js'];
            if (maybeAppJS) {
                return treeFor(this, maybeAppJS, true);
            }
        },
        treeForAddon() {
            // this never goes through broccoli -- it's always pulled into the app via
            // ember-auto-import, as needed. This means it always benefits from
            // tree-shaking.
            return undefined;
        },
        treeForPublic() {
            if (disabled) {
                return undefined;
            }
            let maybeAssets = meta['public-assets'];
            if (maybeAssets) {
                return treeFor(this, maybeAssets);
            }
        },
        cacheKeyForTree(treeType) {
            return `embroider-addon-shim/${treeType}/${directory}`;
        },
        isDevelopingAddon() {
            // if the app is inside our own directory, we must be under development.
            // This setting controls whether ember-cli will watch for changes in the
            // broccoli trees we expose, but it doesn't have any control over our
            // files that get auto-imported into the app. For that, you should use
            // ember-auto-import's watchDependencies option (and this should become
            // part of the blueprint for test apps).
            let appInstance = this._findHost();
            return isInside(directory, appInstance.project.root);
        },
        registerV2Addon(name, root) {
            var _a, _b;
            let parentName;
            if ((0, shared_internals_1.isDeepAddonInstance)(this)) {
                parentName = this.parent.name;
            }
            else {
                parentName = this.parent.name();
            }
            // if we're being used by a v1 package, that package needs ember-auto-import 2
            if (((_b = (_a = this.parent.pkg['ember-addon']) === null || _a === void 0 ? void 0 : _a.version) !== null && _b !== void 0 ? _b : 1) < 2) {
                let autoImport = locateAutoImport(this.parent.addons);
                if (!autoImport.present) {
                    throw new Error(`${parentName} needs to depend on ember-auto-import in order to use ${this.name}`);
                }
                if (!autoImport.satisfiesV2) {
                    throw new Error(`${parentName} has ember-auto-import ${autoImport.version} which is not new enough to use ${this.name}. It needs to upgrade to >=2.0`);
                }
                autoImport.instance.registerV2Addon(name, root);
            }
            else {
                // This should only be done if we're being consumed by an addon
                if (this.parent.pkg['ember-addon'].type === 'addon') {
                    // if we're being used by a v2 addon, it also has this shim and will
                    // forward our registration onward to ember-auto-import
                    this.parent.registerV2Addon(name, root);
                }
            }
        },
    };
}
exports.addonV1Shim = addonV1Shim;
function isInside(parentDir, otherDir) {
    let rel = (0, path_1.relative)(parentDir, otherDir);
    return Boolean(rel) && !rel.startsWith('..') && !(0, path_1.isAbsolute)(rel);
}
function locateAutoImport(addons) {
    let instance = addons.find((a) => a.name === 'ember-auto-import');
    if (!instance) {
        return { present: false };
    }
    let version = instance.pkg.version;
    let satisfiesV2 = (0, semver_1.satisfies)(version, '>=2.0.0-alpha.0', {
        includePrerelease: true,
    });
    if (satisfiesV2) {
        return {
            present: true,
            version,
            satisfiesV2,
            instance: instance,
        };
    }
    else {
        return {
            present: true,
            version,
            satisfiesV2,
        };
    }
}
//# sourceMappingURL=index.js.map