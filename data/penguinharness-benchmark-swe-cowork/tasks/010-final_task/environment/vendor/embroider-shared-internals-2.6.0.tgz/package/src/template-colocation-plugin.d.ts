import type { NodePath } from '@babel/traverse';
import type * as Babel from '@babel/core';
import type { types as t } from '@babel/core';
import { ImportUtil } from 'babel-import-util';
export declare const pluginPath: string;
export interface Options {
    packageGuard?: boolean;
    appRoot: string;
    templateExtensions?: string[];
    exclude?: string[];
}
interface State {
    colocatedTemplate: string | undefined;
    associate: {
        component: t.Identifier;
        template: t.Identifier;
    } | undefined;
    adder: ImportUtil;
    opts: Options;
}
export default function main(babel: typeof Babel): {
    visitor: {
        Program: {
            enter(path: NodePath<Babel.types.Program>, state: State): void;
            exit(path: NodePath<Babel.types.Program>, state: State): void;
        };
        ExportDefaultDeclaration(path: NodePath<Babel.types.ExportDefaultDeclaration>, state: State): void;
        ExportNamedDeclaration(path: NodePath<Babel.types.ExportNamedDeclaration>, state: State): void;
    };
};
export {};
