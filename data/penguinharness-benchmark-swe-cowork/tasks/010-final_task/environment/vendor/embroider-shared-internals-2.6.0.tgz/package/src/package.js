"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const typescript_memoize_1 = require("typescript-memoize");
const fs_extra_1 = require("fs-extra");
const path_1 = require("path");
const get_1 = __importDefault(require("lodash/get"));
const flatMap_1 = __importDefault(require("lodash/flatMap"));
class Package {
    constructor(root, packageCache, isApp) {
        this.root = root;
        this.packageCache = packageCache;
        this.isApp = isApp;
        this.dependencyKeys = isApp
            ? ['dependencies', 'devDependencies', 'peerDependencies']
            : ['dependencies', 'peerDependencies'];
    }
    get name() {
        return this.packageJSON.name;
    }
    get version() {
        return this.packageJSON.version;
    }
    get internalPackageJSON() {
        return JSON.parse((0, fs_extra_1.readFileSync)((0, path_1.join)(this.root, 'package.json'), 'utf8'));
    }
    get packageJSON() {
        let json = this.internalPackageJSON;
        if (this.nonResolvableDeps) {
            if (!json.dependencies) {
                json.dependencies = {};
            }
            for (let dep of this.nonResolvableDeps.values()) {
                json.dependencies[dep.name] = dep.version || '*';
            }
        }
        return json;
    }
    get meta() {
        let m = this.packageJSON['ember-addon'];
        if (this.isV2App()) {
            return m;
        }
        if (this.isV2Addon()) {
            return m;
        }
    }
    isEmberPackage() {
        let keywords = this.packageJSON.keywords;
        return Boolean(keywords && keywords.includes('ember-addon'));
    }
    isEngine() {
        if (this.isApp) {
            // an app is implicitly an engine
            return true;
        }
        let keywords = this.packageJSON.keywords;
        return Boolean(keywords && keywords.includes('ember-engine'));
    }
    isLazyEngine() {
        return this.isEngine() && Boolean((0, get_1.default)(this.packageJSON, 'ember-addon.lazy-engine'));
    }
    isV2Ember() {
        return this.isEmberPackage() && (0, get_1.default)(this.packageJSON, 'ember-addon.version') === 2;
    }
    isV2App() {
        return this.isV2Ember() && this.packageJSON['ember-addon'].type === 'app';
    }
    isV2Addon() {
        return this.isV2Ember() && this.packageJSON['ember-addon'].type === 'addon';
    }
    findDescendants(filter) {
        let pkgs = new Set();
        let queue = [this];
        while (true) {
            let pkg = queue.shift();
            if (!pkg) {
                break;
            }
            if (!pkgs.has(pkg)) {
                pkgs.add(pkg);
                let nextLevel;
                if (filter) {
                    nextLevel = pkg.dependencies.filter(filter);
                }
                else {
                    nextLevel = pkg.dependencies;
                }
                nextLevel.forEach(d => queue.push(d));
            }
        }
        pkgs.delete(this);
        return [...pkgs.values()];
    }
    get mayRebuild() {
        // if broccoli memoization is enabled, allowing addons to rebuild
        // automatically is cheap, so we allow all addons to rebuild.
        if (process.env['BROCCOLI_ENABLED_MEMOIZE'] === 'true') {
            return true;
        }
        // Otherwise, we only allow addons to rebuild that you've explicitly asked for
        // via env var.
        if (process.env.EMBROIDER_REBUILD_ADDONS) {
            if (process.env.EMBROIDER_REBUILD_ADDONS.split(',').includes(this.name)) {
                return true;
            }
        }
        return false;
    }
    get nonResolvableDeps() {
        let meta = this.internalPackageJSON['ember-addon'];
        if (meta && meta.paths) {
            return new Map(meta.paths
                .map((path) => {
                var _a;
                // ember-cli gives a warning if the path specifies an invalid, malformed or missing addon. the logic for invalidating an addon is:
                // https://github.com/ember-cli/ember-cli/blob/627934f91b2aa0e19b041fdb1b547873c1855793/lib/models/package-info-cache/index.js#L427
                //
                // Note that we only need to be this lenient with in-repo addons,
                // which is why this logic is here in nonResolvableDeps. If you try
                // to ship broken stuff in regular dependencies, NPM is going to
                // stop you.
                let pkg, main;
                try {
                    pkg = this.packageCache.get((0, path_1.join)(this.root, path));
                    main = ((_a = pkg.packageJSON['ember-addon']) === null || _a === void 0 ? void 0 : _a.main) || pkg.packageJSON['main'];
                }
                catch (err) {
                    // package was missing or had invalid package.json
                    return false;
                }
                if (!main || main === '.' || main === './') {
                    main = 'index.js';
                }
                else if (!(0, path_1.extname)(main)) {
                    main = `${main}.js`;
                }
                let mainPath = (0, path_1.join)(this.root, path, main);
                if (!(0, fs_extra_1.existsSync)(mainPath)) {
                    // package has no valid main
                    return false;
                }
                return [pkg.name, pkg];
            })
                .filter(Boolean));
        }
    }
    get dependencyNames() {
        return (0, flatMap_1.default)(this.dependencyKeys, key => Object.keys(this.packageJSON[key] || {}));
    }
    // this answers the question, "why is this thing in `this.dependencies`?". The
    // order of the dependency keys is important, because "dependencies" always
    // dominates (if it's your dependency, it's always your dependency). Next
    // comes devDependencies, so that if you're the topmost package, your
    // devDependencies are active dependenceis. Last comes peerDependencies. It's
    // common for a peerDep to also appear in devDependencies, but unless your
    // pacakge is the topmost your devDependencies won't be included in
    // this.dependencyKeys, so we'll see that you are now getting the package via
    // peerDeps.
    categorizeDependency(name) {
        var _a;
        for (let key of this.dependencyKeys) {
            if ((_a = this.packageJSON[key]) === null || _a === void 0 ? void 0 : _a[name]) {
                return key;
            }
        }
    }
    get dependencies() {
        return this.dependencyNames
            .map(name => {
            if (this.nonResolvableDeps) {
                let dep = this.nonResolvableDeps.get(name);
                if (dep) {
                    return dep;
                }
            }
            try {
                return this.packageCache.resolve(name, this);
            }
            catch (error) {
                // if the package was not found do not error out here. this is relevant
                // for the case where a package might be an optional peerDependency and we dont
                // want to error if it was not found. Additionally, erroring here is "far" away
                // from the actual logical failure point and so not failing here will provide a better
                // error message down the line
                if (error.code === 'MODULE_NOT_FOUND') {
                    return false;
                }
                throw error;
            }
        })
            .filter(Boolean);
    }
    hasDependency(name) {
        for (let section of this.dependencyKeys) {
            if (this.packageJSON[section]) {
                if (this.packageJSON[section][name]) {
                    return true;
                }
            }
        }
        return false;
    }
}
exports.default = Package;
__decorate([
    (0, typescript_memoize_1.Memoize)()
], Package.prototype, "internalPackageJSON", null);
__decorate([
    (0, typescript_memoize_1.Memoize)()
], Package.prototype, "packageJSON", null);
__decorate([
    (0, typescript_memoize_1.Memoize)()
], Package.prototype, "nonResolvableDeps", null);
__decorate([
    (0, typescript_memoize_1.Memoize)()
], Package.prototype, "dependencies", null);
//# sourceMappingURL=package.js.map