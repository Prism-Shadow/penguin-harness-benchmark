/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_codemappair_free(a: number, b: number): void;
export function __wbg_get_codemappair_code(a: number): Array;
export function __wbg_set_codemappair_code(a: number, b: number, c: number): void;
export function __wbg_get_codemappair_map(a: number): Array;
export function __wbg_set_codemappair_map(a: number, b: number, c: number): void;
export function codemappair_new(a: number, b: number, c: number, d: number): number;
export function __wbg_preprocessor_free(a: number, b: number): void;
export function preprocessor_new(): number;
export function preprocessor_process(a: number, b: number, c: number, d: number): Array;
export function preprocessor_parse(a: number, b: number, c: number, d: number): Array;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function __wbindgen_free(a: number, b: number, c: number): void;
export function __externref_table_dealloc(a: number): void;
export function __wbindgen_exn_store(a: number): void;
export function __externref_table_alloc(): number;
export function __wbindgen_start(): void;
