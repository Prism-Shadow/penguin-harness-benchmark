/* tslint:disable */
/* eslint-disable */
export class CodeMapPair {
  free(): void;
  /**
   * @param {string} code
   * @param {string} map
   */
  constructor(code: string, map: string);
  code: string;
  map: string;
}
export class Preprocessor {
  free(): void;
  constructor();
  /**
   * @param {string} src
   * @param {any} options
   * @returns {CodeMapPair}
   */
  process(src: string, options: any): CodeMapPair;
  /**
   * @param {string} src
   * @param {any} options
   * @returns {any}
   */
  parse(src: string, options: any): any;
}
