<?php

declare(strict_types=1);

namespace MongoDB\Laravel\Query;

use Illuminate\Database\Query\Builder;
use MongoDB\Laravel\Schema\BlueprintLaravelCompatibility;

use function dirname;
use function is_file;
use function method_exists;

// The cumulative source keeps this legacy surface only while its matching
// pre-Laravel-12 Blueprint compatibility layer is present.
$blueprintCompatibilityFile = dirname(__DIR__) . '/Schema/BlueprintLaravelCompatibility.php';

if (is_file($blueprintCompatibilityFile) && trait_exists(BlueprintLaravelCompatibility::class)) {
    if (method_exists(Builder::class, 'timeout')) {
        trait BuilderTimeout
        {
        }
    } else {
        trait BuilderTimeout
        {
            /** @var int|float */
            public $timeout;

            public function timeout($seconds)
            {
                $this->timeout = $seconds;

                return $this;
            }
        }
    }
}
