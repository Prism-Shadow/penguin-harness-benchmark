# flags: --skip-string-normalization
class C:

    r"""Raw"""

def f():

    r"""Raw"""

class SingleQuotes:


    r'''Raw'''

class UpperCaseR:
    R"""Raw"""

# output
class C:
    r"""Raw"""


def f():
    r"""Raw"""


class SingleQuotes:
    r'''Raw'''


class UpperCaseR:
    R"""Raw"""
