# flags: --minimum-version=3.10
def http_status(status):

    match status:

        case 400:

            return "Bad request"

        case 401:

            return "Unauthorized"

        case 403:

            return "Forbidden"

        case 404:

            return "Not found"

# output
def http_status(status):

    match status:

        case 400:

            return "Bad request"

        case 401:

            return "Unauthorized"

        case 403:

            return "Forbidden"

        case 404:

            return "Not found"