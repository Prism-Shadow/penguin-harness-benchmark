# flags: --unstable
f"{''=}" f'{""=}'