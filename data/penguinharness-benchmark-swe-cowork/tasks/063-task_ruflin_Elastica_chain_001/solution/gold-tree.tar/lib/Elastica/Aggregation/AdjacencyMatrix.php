<?php

namespace Elastica\Aggregation;

use Elastica\Exception\InvalidException;
use Elastica\Query\AbstractQuery;

class AdjacencyMatrix extends AbstractAggregation
{
    /**
     * Add a named filter.
     *
     * @param string $name
     *
     * @return $this
     */
    public function addFilter(AbstractQuery $filter, $name): self
    {
        if (!\is_string($name)) {
            throw new InvalidException('Name must be a string');
        }

        $filterArray = [];
        $filterArray[$name] = $filter;

        return $this->addParam('filters', $filterArray);
    }

    /**
     * @return $this
     */
    public function setSeparator(string $separator = '&'): self
    {
        return $this->setParam('separator', $separator);
    }

    public function toArray(): array
    {
        $array = parent::toArray();
        $array['adjacency_matrix']['filters'] = [];

        foreach ($this->getParam('filters') as $filter) {
            $name = \key($filter);
            $array['adjacency_matrix']['filters'][$name] = \current($filter)->toArray();
        }

        return $array;
    }
}
