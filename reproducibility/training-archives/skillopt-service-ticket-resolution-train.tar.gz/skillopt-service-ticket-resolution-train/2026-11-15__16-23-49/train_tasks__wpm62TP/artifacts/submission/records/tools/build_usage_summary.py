import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

root=Path('/app/submission/records')
def phase_for(rel):
    s=rel.as_posix()
    if s.startswith('baseline/'): return 'baseline_selection'
    if '/rollout/' in s: return 'fast_rollout'
    if '/candidate_selection/' in s: return 'fast_candidate_selection'
    if '/slow_comparison/previous/' in s: return 'slow_comparison_previous'
    if '/slow_comparison/current/' in s: return 'slow_comparison_current'
    if '/slow_selection/' in s: return 'slow_candidate_selection'
    return 'other'

records=[]
for result_path in sorted(root.rglob('result.json')):
    r=json.loads(result_path.read_text())
    rec=result_path.parent
    rel=rec.relative_to(root)
    usage=r.get('usage',[])
    sums=defaultdict(int)
    for u in usage:
        for k in ('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens'):
            sums[k]+=int(u.get(k,0) or 0)
    feedback=rec/'judge-feedback.json'
    records.append({
        'record': str(rel),
        'role': r.get('role'),
        'task': r.get('task'),
        'complete': bool(r.get('complete')),
        'restricted_command_detected': bool(r.get('restricted_command_detected')),
        'skill_unchanged': r.get('skill_unchanged'),
        'session_id': r.get('session_id'),
        'phase': phase_for(rel),
        'usage': dict(sums),
        'judge_feedback_present': feedback.is_file(),
        'score': json.loads(feedback.read_text()).get('score') if feedback.is_file() else None,
        'result_mtime': datetime.fromtimestamp(result_path.stat().st_mtime,timezone.utc).isoformat(),
    })
by_phase=defaultdict(lambda:{'attempts':0,'input_tokens':0,'cached_input_tokens':0,'cache_write_input_tokens':0,'output_tokens':0,'reasoning_output_tokens':0})
overall={'attempts':0,'input_tokens':0,'cached_input_tokens':0,'cache_write_input_tokens':0,'output_tokens':0,'reasoning_output_tokens':0}
for r in records:
    p=by_phase[r['phase']]; p['attempts']+=1
    for k in ('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens'):
        p[k]+=r['usage'].get(k,0); overall[k]+=r['usage'].get(k,0)
    overall['attempts']+=1
mtimes=[datetime.fromisoformat(r['result_mtime']) for r in records]
summary={
  'source':'actor result.json usage records; every delegated attempt retained under records/',
  'model':'deepseek-flash','thinking_level':'max',
  'attempt_count':len(records),
  'all_attempts_complete':all(r['complete'] for r in records),
  'all_answers_have_feedback':all(r['judge_feedback_present'] for r in records),
  'restricted_command_count':sum(r['restricted_command_detected'] for r in records),
  'overall':overall,
  'by_phase':dict(sorted(by_phase.items())),
  'artifact_span':{'first_result_mtime':min(mtimes).isoformat(),'last_result_mtime':max(mtimes).isoformat(),'seconds':round((max(mtimes)-min(mtimes)).total_seconds())},
  'attempts':records,
  'note':'input_tokens includes cached_input_tokens where reported by the runtime; cost is not fabricated because no per-token billing schedule was supplied.'
}
(root/'usage_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('attempt_count','all_attempts_complete','all_answers_have_feedback','restricted_command_count','overall','by_phase','artifact_span')},indent=2))
