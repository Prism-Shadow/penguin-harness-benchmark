# Optimizer Meta Guidance

- Strong evidence: explicit decision tables reduce inconsistent blocker-to-route mapping.
- Preserve the measured-success rules for ticket dimensions, mobile action choice, and exact output arithmetic.
- Enterprise fields require evidence-specific naming and a readiness decision, not merely transcription.
- Avoid task identifiers or instance answers in the Skill.

## Epoch 2 reflection
- A candidate can restore the incumbent score while changing multiple fields; ties do not reveal a winning direction.
- Broad enterprise naming/permission rewrites were not beneficial enough to clear the gate.
- Protected slow guidance should retain only rules supported by repeated persistent failures.

## Epoch 2 slow/meta update
- Protected guidance duplicating fast-patch lessons tied; only concise rules with demonstrated transitions should survive.
- Persistent enterprise uncertainty is concentrated in root-cause label, evidence-folder naming, and readiness rather than date arithmetic.
- Persistent queue uncertainty is concentrated in when a remediated provisioning ticket changes from escalation to resolution.

## Epoch 3 slow/meta update
- Evidence-to-success: unresolved authentication is FAILED/tier-2 with diagnostic false; collaborator permission is edit.
- Preserve the simple full-legal-name report title and plain client-date investigation folder; decorative extra words can regress a corrected folder.
- The queue residual blocker changes did not improve the aggregate; avoid expanding speculative blocker mappings without a score gain.

## Epoch 4 final slow/meta update
- Escalating a still-impaired applied provisioning repair is correct; changing it to pending regressed the score.
- Enforcing simple legal-name report title and plain client-date folder is necessary, but protected instructions must simultaneously retain the last-failed-run end date; the final slow candidate regressed by losing that boundary.
- Final retained skill is v2, not the later candidates. Later changes never cleared the strict gate.
