#!/usr/bin/env python3
import sys
from pathlib import Path

def parse_hunks(patch_text):
    hunks=[]; old=[]; new=[]; in_hunk=False
    for line in patch_text.splitlines():
        if line.startswith('@@ '):
            if in_hunk: hunks.append((old,new))
            old=[]; new=[]; in_hunk=True
        elif not in_hunk or line.startswith(('--- ','+++ ')):
            continue
        elif line.startswith(' '): old.append(line[1:]); new.append(line[1:])
        elif line.startswith('-') and not line.startswith('--- '): old.append(line[1:])
        elif line.startswith('+') and not line.startswith('+++ '): new.append(line[1:])
    if in_hunk: hunks.append((old,new))
    return hunks

def main():
    target=Path(sys.argv[1]); patch=Path(sys.argv[2])
    text=target.read_text()
    hunks=parse_hunks(patch.read_text())
    for i,(old,new) in enumerate(hunks,1):
        before='\n'.join(old); after='\n'.join(new)
        count=text.count(before)
        if count != 1: raise SystemExit(f'hunk {i}: expected one match, found {count}')
        text=text.replace(before,after,1)
        print(f'applied hunk {i}')
    target.write_text(text)
    print(f'applied {len(hunks)} hunks')

if __name__=='__main__': main()
