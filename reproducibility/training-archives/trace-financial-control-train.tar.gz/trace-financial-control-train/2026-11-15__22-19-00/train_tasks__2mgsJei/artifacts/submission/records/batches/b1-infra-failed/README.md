# B1 incomplete execution

`train_003/attempt_01` completed a model turn and wrote a candidate, but the bridge marked it incomplete because the required machine-readable skill-selection artifact was absent. It has no judge feedback and is excluded from training measurements. Its transcript, result and candidate are retained unchanged for audit.

A fresh replacement attempt under the same frozen B1 bank is recorded under `batches/b1/train_003/attempt_01`. The original candidate was never submitted to the judge.
