#!/usr/bin/env python3
"""Validate a deployed TRACE bank's catalog, entry metadata and fixed reader."""
import hashlib
import json
import re
import sys
from pathlib import Path


def parse_catalog(path: Path) -> list[dict]:
    text = path.read_text()
    if text.strip() == 'skills: []':
        return []
    entries = []
    current = None
    for line in text.splitlines()[1:]:
        match = re.match(r'^  - id: (.+)$', line)
        if match:
            current = {'id': match.group(1).strip()}
            entries.append(current)
            continue
        match = re.match(r'^    (description|path): (.+)$', line)
        if match and current is not None:
            current[match.group(1)] = match.group(2).strip()
    return entries


def frontmatter(text: str) -> dict[str, str]:
    if not text.startswith('---\n'):
        return {}
    block = text.split('\n---\n', 1)[0][4:]
    result = {}
    for line in block.splitlines():
        if ': ' in line:
            key, value = line.split(': ', 1)
            result[key] = value
    return result


def main() -> None:
    root = Path(sys.argv[1])
    catalog = parse_catalog(root / 'catalog.yaml')
    errors = []
    ids = [entry['id'] for entry in catalog]
    if len(ids) != len(set(ids)):
        errors.append('catalog ids are not unique')
    files = sorted(p.relative_to(root).as_posix() for p in (root / 'entries').glob('*/SKILL.md'))
    expected = sorted(entry['path'] for entry in catalog)
    if files != expected:
        errors.append(f'catalog/files differ: files={files} expected={expected}')
    reader = (root / 'SKILL.md').read_text()
    fixed_marker = 'Read catalog.yaml beside this file at task start.'
    if fixed_marker not in reader or 'Keep this bank fixed during execution' not in reader:
        errors.append('fixed reader body marker missing')
    details = []
    for entry in catalog:
        skill_id = entry['id']
        if not re.fullmatch(r'trace-[a-z0-9-]{1,58}', skill_id):
            errors.append(f'invalid id: {skill_id}')
        path = root / entry['path']
        if not path.is_file():
            errors.append(f'missing entry: {path}')
            continue
        text = path.read_text()
        meta = frontmatter(text)
        body = text.split('\n---\n', 1)[1].strip() if '\n---\n' in text else ''
        if meta.get('name') != skill_id:
            errors.append(f'frontmatter name mismatch: {skill_id}')
        if meta.get('description') != entry.get('description'):
            errors.append(f'description mismatch: {skill_id}')
        if not meta.get('version') or not body:
            errors.append(f'missing version/body: {skill_id}')
        details.append({'id': skill_id, 'path': entry['path'],
                        'bytes': len(text.encode()), 'body_bytes': len(body.encode())})
    digest = hashlib.sha256()
    for path in sorted(p for p in root.rglob('*') if p.is_file()):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(b'\0')
        digest.update(path.read_bytes())
        digest.update(b'\0')
    result = {'bank': str(root), 'digest': digest.hexdigest(), 'entry_count': len(catalog),
              'entries': details, 'valid': not errors, 'errors': errors}
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else root / 'validation.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
