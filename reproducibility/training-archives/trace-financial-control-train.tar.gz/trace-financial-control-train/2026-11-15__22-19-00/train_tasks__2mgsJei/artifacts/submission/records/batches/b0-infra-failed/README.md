# B0 infrastructure failures

Two B0 `train_001` Actor sessions were launched with the frozen B0 bank and then lost during repeated model-transport connection failures. Neither reached an answer, completed a turn, or called the training judge. The raw partial event streams and stderr logs are preserved under `train_001_run/`.

These are failed infrastructure attempts, not scored observations. Fresh replacement sessions use the same frozen bank and are recorded under `batches/b0/`.
