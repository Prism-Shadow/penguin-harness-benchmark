# TRACE training records

This directory contains the training evidence for one continuous five-task financial-control unit. H1 is the empty-bank baseline; B0, B1 and B2 are complete measured batches of two fresh Actor attempts per task under their frozen bank digests.

- `batches/<stage>/<task>/attempt_XX/`: raw Codex event stream, session result, candidate answer, selection record, raw judge feedback binding and usage.
- `feedback/<stage>/`: the one permitted raw judge response per completed answer.
- `bootstrap/`: four-stage B0 analysis and validation.
- `proposals/` and `publications/`: staged revisions, evidence and accepted snapshots.
- `evolution/`: per-round grouping, diagnoses, batch summaries and validation.
- `stage-snapshots/`: exact frozen H1/B0/B1/B2 bank contents.
- `batches/*-infra-failed/`: preserved incomplete infrastructure sessions, excluded from scores and never submitted to the judge.
- `selection.yaml`: fixed `best_train` ranking and selected checkpoint.

No answer values, feedback, case identifiers or optimizer history were copied into the deployed Skill.
