---
name: finance-control-erp-close
description: Reconcile current ERP finance records for expense and AP close, scoped prepaid amortization, and vendor compliance release. Use when a task requires paginated API evidence, exact-decimal money, explicit ID joins, stale-snapshot correction, or template-conforming JSON.
---

# Finance Control ERP Close

Use this library as a reader for finance-control work: establish current evidence first, then route to the accounting decision module named by the task. The shared API is the system of record; the public instruction and answer template are the output contract.

## Non-negotiable controls

- Read the instruction, answer template, scope file, and every public payload before querying. Extract required keys, allowed enums, dates, ordering, thresholds, signs, and status precedence from those artifacts.
- Query only endpoints allowed by the public environment contract. Do not call scoring, judge, private-test, or target-feedback endpoints.
- Treat API records as current evidence. Use local exports or snapshots only for the comparison the public task requests; never let a snapshot override a current API row.
- Keep source identifiers and raw field values in the audit trail. Never fabricate a missing record or infer its values from a name or narrative.
- Use exact decimal arithmetic with `Decimal`; do not use binary floats for money. Round only at the final output boundary unless the contract states otherwise.
- Validate collection completeness, uniqueness, joins, sums, sort order, enum membership, and exact JSON shape before writing output.

## Route the task

| Required evidence or decision | Load |
| --- | --- |
| Pagination, normalization, current-vs-stale comparison, dates, money, ID joins, audit trail | `erp-evidence-reconciliation/SKILL.md` |
| Claim-to-AP-bill-to-payment close, open AP balance, blockers, close logs, reimbursement batch posture | `expense-ap-close/SKILL.md` |
| Scoped straight-line prepaid schedules, amortization, exceptions, GL rollups and variances | `prepaid-close/SKILL.md` |
| Ownership counts, vendor onboarding, account-change controls, compliance hard stops and release posture | `vendor-compliance-release/SKILL.md` |

For mixed tasks, load `erp-evidence-reconciliation` first and the applicable decision module(s) next. Do not blend a module's status vocabulary into another task; task-specific enums always win.

## Working sequence

1. Freeze the requested universe: explicit IDs, entity, period, date, accounts, threshold, and output order.
2. Discover the live endpoints and response envelope. Fetch all required records with exact-match filters where supported; paginate any list response.
3. Normalize records and build unique-key maps. Reconcile list counts and detect duplicates or missing links.
4. Join only by explicit identifiers. Compare amounts, currencies, statuses, dates, and parent-child links rather than assuming a status is settlement evidence.
5. Apply the routed module's classification or schedule logic. Preserve the distinction between source-evidence issues and accounting-policy issues.
6. Recompute every total from normalized rows. Reconcile row totals to aggregates and schedule ending balances to GL balances using the contract's stated sign.
7. Emit the exact template shape. Sort every ID list as directed, use two-decimal JSON numbers, and include no keys the contract disallows.

## Shared references

- `references/api-evidence.md`: endpoint families, pagination, identifiers, current-record rules, and money/date handling.
- `references/contract-validation.md`: output-contract extraction, status precedence, decimal serialization, and final reconciliation checks.

Record an unresolved policy ambiguity in the construction/audit notes and follow the template's explicit contract. Do not invent a policy, threshold, status, or record to fill a gap.
