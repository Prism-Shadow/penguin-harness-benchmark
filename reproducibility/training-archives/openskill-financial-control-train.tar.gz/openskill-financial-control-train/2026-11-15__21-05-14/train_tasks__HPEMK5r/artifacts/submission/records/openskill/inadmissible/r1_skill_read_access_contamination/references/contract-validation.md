# Contract Validation

## Extract the contract before calculation

Turn the public template into a checklist:

- required top-level keys and whether extra keys are allowed;
- required object keys and their value types;
- allowed enums and their exact spelling;
- required members and sort order;
- date formats, fixed values, units, signs, thresholds, and minimums;
- whether numbers are money, counts, percentages, or booleans;
- special rules such as "use empty list when none apply."

Read the task instruction and every payload as one contract. If prose and template differ, follow the template's explicit structural contract and record the ambiguity; do not add a field to express the conflict.

## Classification precedence

Use a documented decision order rather than applying several labels at once:

1. establish requested universe and current evidence;
2. identify hard blockers from explicit status/support/identity fields;
3. identify settled or completed items;
4. classify remaining valid open items;
5. derive aggregate and batch status from the resulting sets.

Unless the public contract says otherwise, a hard blocker takes precedence over an otherwise open item; a fully matched settlement takes precedence over an open classification; and aggregate status follows the template's stated priority. Never assign a label solely because a list name sounds similar to a source status.

## Decimal output and structure

- Build the answer as a structured object, not by string concatenation.
- Emit money as JSON numbers with exactly two decimal digits in the serialized text (for example `0.00`, `1842.36`), not as quoted strings unless the template requires strings.
- Keep whole-number counts as integers and flags as booleans.
- Do not include comments, Markdown fences, source records, or explanatory narrative in a JSON-only answer.
- Validate that sorted lists are in the required direction and that invoice lists preserve scope order when the template asks for it.

## Reconciliation before writing

- Compare the number of reviewed IDs with the union of all classification lists and explain any non-classified item.
- Recompute every aggregate from included rows; do not copy a source total without checking row-level arithmetic.
- Reconcile schedule totals by account and confirm `variance = schedule ending balance - GL ending balance` when that sign is specified.
- Check that status/flag fields agree with the sets they summarize (for example, `has_*` flags match at least one qualifying row).
- Confirm no stale value survives when the current API row changes it.
- Re-open the JSON with a parser and compare its keys, types, enum values, and ordering against the template checklist.
