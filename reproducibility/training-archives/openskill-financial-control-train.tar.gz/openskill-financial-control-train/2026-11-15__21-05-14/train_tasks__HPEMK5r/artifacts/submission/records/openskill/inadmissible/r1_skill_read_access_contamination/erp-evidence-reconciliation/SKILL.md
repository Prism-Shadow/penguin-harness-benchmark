---
name: erp-evidence-reconciliation
description: Build current, paginated ERP evidence sets and reconcile records by explicit IDs and dates using exact decimal money. Use before expense/AP, prepaid, or vendor-compliance decisions, especially when stale exports or partial matches are involved.
---

# ERP Evidence Reconciliation

Establish what the current system says before deciding a close. Read the root `SKILL.md`, `references/api-evidence.md`, and `references/contract-validation.md`, then work in this order.

## 1. Freeze the request

Write down:

- explicit claim, bill, payment, invoice, vendor, business, and log IDs;
- entity, period, review/as-of date, accounts, and threshold;
- required fields, enums, signs, and list ordering;
- whether a local snapshot is candidates-only, a comparison baseline, or forbidden as evidence.

The requested ID universe is closed unless the public instruction explicitly allows expansion. Query related rows only through those IDs or explicit foreign keys.

## 2. Discover and page the API

1. Read the endpoint inventory and identify canonical and alias routes.
2. Prefer exact-match filters for explicit IDs. If a filter is unavailable or returns an unexpected schema, retrieve and page the collection, then filter locally by exact ID.
3. For each collection, save the first response's `total`; advance `offset` by the number of rows returned until unique rows equal `total` or an empty page is reached.
4. Reconcile `count`, unique IDs, and `total`. If they differ, report missing or duplicate records rather than filling gaps.
5. For anything requested for a specific decision, fetch the underlying records even when an aging/derived endpoint already shows a balance.

Do not query scoring, judge, hidden-test, or target-feedback routes.

## 3. Normalize

Create one row per stable source object containing:

- source endpoint and exact filters;
- stable ID and parent IDs;
- status, void/active marker, currency, raw amount, and date fields;
- currentness fields when present;
- inclusion/exclusion reason and any duplicate/missing-link observation.

Keep raw values alongside converted `Decimal` and `date` values. Do not rewrite an API status to an answer enum until the decision module has applied the public mapping.

## 4. Resolve current versus stale

- Current API rows are authoritative. Use a local export only to identify what changed or to fill a correction field expressly requested by the template.
- Match snapshot rows to current rows by the stable business ID, not by position or approximate name.
- Compare the relevant fields separately:
  - claim status/support/amount/vendor;
  - bill status/amount/vendor/validity;
  - payment status/amount/method/date and whether funds cleared;
  - compliance/bank/tax/license fields.
- If a snapshot says paid but current payment is processing, the current item is not settled. If a snapshot shows an open row but current evidence contains a matched void bill, retain the current void status and select the correction the template provides.
- If current evidence is absent or contradictory, mark the evidence gap and use the contract's blocker/follow-up value. Do not carry forward the stale assertion.

## 5. Join and test relationships

Use explicit keys:

```text
claim.claim_id -> bill.claim_id
bill.bill_id -> payment.bill_id
vendor.vendor_id -> claim/bill/payment/compliance object
compliance.business_id -> ownership/registry/screening/bank detail
invoice.prepaid_invoice_id -> scope and invoice_results
GL (entity, account, period) -> account_rollup
```

A join succeeds only when the relationship fields agree and the public decision rule is met. Test amount equality to cents, currency equality, vendor equality where stated, non-void status, and cleared payment state. A matched status word alone is insufficient.

For one-to-many relationships, retain every child row. Select a single bill only when exactly one meets the stated validity tests and all others are explicitly void/excluded; otherwise surface ambiguity.

## 6. Exact money and dates

- Parse decimals from JSON text with `Decimal`; never add monetary values as Python floats.
- Sum the included rows, then compare to any API-provided balance or total. Recompute rather than copying a derived total when the task asks for a reconciliation.
- Round only the output amount to cents with the contract's rule. Keep enough precision in intermediate cumulative balances to avoid cent drift.
- Use the explicit review/as-of/period date. Store dates as dates, compare expiry at the contract boundary, and document whether date equality counts as valid.

## 7. Produce the evidence trail

For each requested ID, record:

```text
ID | current source row(s) | linked row(s) | amount(s)/balance | status evidence | test result | excluded row and reason | contract label
```

Then reconcile:

- requested count = union of output classifications;
- payable/open total = sum of included valid open rows;
- schedule total = sum of selected invoice rows;
- list membership = recomputed flag/status;
- sort order and template keys = exact contract.

If a needed policy value, ID, date, or threshold is absent from public inputs, document the ambiguity. Do not invent it from an answer-shaped assumption.
