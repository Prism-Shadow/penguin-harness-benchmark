#!/usr/bin/env python3
"""Reconstruct exact OpenSkill Skill snapshots from Codex thread file-change items."""
import json
import sqlite3
from pathlib import Path

DB = Path('/tmp/codex-home/thread_history_1.sqlite')
THREAD = '01a1df59-5405-7952-bbd6-e08f2333e6c4'
SCOPE = '/app/submission/records/openskill/skill_current/'
OUT = Path('/app/submission/records/openskill/revisions')


def apply_hunk(text: str, diff: str) -> str:
    old = text.splitlines(keepends=True)
    out = []
    cursor = 0
    lines = diff.splitlines(keepends=True)
    idx = 0
    while idx < len(lines):
        if not lines[idx].startswith('@@ '):
            idx += 1
            continue
        header = lines[idx].rstrip('\n')
        idx += 1
        old_start = int(header.split(' ')[1][1:].split(',')[0])
        start = max(old_start - 1, 0)
        out.extend(old[cursor:start])
        cursor = start
        while idx < len(lines) and not lines[idx].startswith('@@ '):
            line = lines[idx]
            if line.startswith('\\ No newline'):
                idx += 1
                continue
            lead, body = line[:1], line[1:]
            if lead in (' ', '-'):
                assert old[cursor] == body, (cursor + 1, old[cursor], body)
                if lead == ' ':
                    out.append(old[cursor])
                cursor += 1
            elif lead == '+':
                out.append(body)
            else:
                raise ValueError(f'bad diff line {line!r}')
            idx += 1
    out.extend(old[cursor:])
    return ''.join(out)


con = sqlite3.connect(DB)
turn_ids = [r[0] for r in con.execute(
    'select turn_id from thread_turns where thread_id=? order by rollout_ordinal', (THREAD,))]
assert len(turn_ids) == 3, turn_ids
names = dict(zip(turn_ids, ('r2_skill', 'r3_skill', 'r4_skill')))
files = {}
for turn_id in turn_ids:
    rows = list(con.execute(
        'select item_json from thread_items where thread_id=? and turn_id=? and item_type="fileChange" order by rollout_ordinal',
        (THREAD, turn_id)))
    for (item_json,) in rows:
        for change in json.loads(item_json)['changes']:
            path = change['path']
            if not path.startswith(SCOPE):
                continue
            rel = path[len(SCOPE):]
            kind = change['kind']['type']
            diff = change.get('diff', '')
            if kind == 'add':
                files[rel] = diff
            elif kind == 'update':
                assert rel in files, f'update before add: {rel}'
                files[rel] = apply_hunk(files[rel], diff)
            else:
                raise ValueError(kind)
    target = OUT / names[turn_id]
    for rel_path, content in files.items():
        dest = target / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding='utf-8')
    print(names[turn_id], len(files), 'files', len(rows), 'change items')
