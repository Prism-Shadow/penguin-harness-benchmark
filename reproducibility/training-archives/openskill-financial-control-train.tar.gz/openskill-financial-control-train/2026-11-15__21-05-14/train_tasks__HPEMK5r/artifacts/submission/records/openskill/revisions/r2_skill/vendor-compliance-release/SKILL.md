---
name: vendor-compliance-release
description: Evaluate current vendor, ownership, tax, license, bank, screening, sanctions, PEP, and risk evidence for onboarding or account-change release.
---

# Vendor Compliance Release

Use this module for vendor onboarding decisions, payment release after account-change events, reportable-owner counts, hard-stop flags, follow-up queues, and risk overrides.

Read `erp-evidence-reconciliation/SKILL.md` and `../references/erp-evidence-protocol.md` before acting.

## Current-evidence collection

For each requested business ID:

1. Query the compliance object by exact `business_id` to obtain the linked vendor ID, review state, missing fields, risk score, and current summary fields.
2. Query ownership, registry, screening, and bank detail endpoints by the same business ID.
3. Query the vendor record by the object's `vendor_id`.
4. Verify every returned record contains the requested business or vendor ID. Never attach a detail record from a similar entity.
5. Use the current detailed evidence, not the local ticket's asserted status. For account changes, also compare the requested bank last four with the current vendor bank last four when the task supplies it.

## Reportable owners

Apply the reporting threshold supplied by the task or an authoritative public rule. If no threshold is supplied, document the ambiguity; do not invent a threshold.

Filter ownership entries using the threshold comparison stated by the task (`at or above` is normally inclusive). Normalize a person's name only for exact de-duplication (trim/case-fold) and count unique names among qualifying entries. Do not count raw rows when the same owner name repeats. Do not aggregate distinct records unless the active task explicitly says to aggregate ownership percentages.

Report zero when no unique owner meets the threshold.

## Hard-stop evidence

Evaluate all current evidence and map only conditions explicitly represented by the active template. Check these classes:

- bank state: closed, name mismatch, not verified;
- tax: missing, malformed, placeholder, or inconsistent between compliance and vendor records;
- license: missing or expired relative to the as-of date;
- required documents: nonempty `missing_fields` and any task-defined mandatory field subset;
- screening: sanctions or PEP checks not run, possible match, or confirmed match;
- ownership risk: suspected shell company, unusual layer depth when the task supplies a rule;
- vendor lifecycle: on hold or inactive;
- risk score: apply the task's explicit override threshold, including equality when it says `>=`;
- account-change bank target: requested last four must agree with the current vendor bank record when that check is required.

Use exact enum strings from the template. Sort hard-stop lists exactly as instructed. Do not emit a hard stop merely because the source review status is not approved.

## Decision mapping

Use the decision enum from the active template and separate severe escalation from correctable evidence gaps:

- release/approve only when all required release checks pass and the risk override rule is not triggered;
- use the template's informational/hold outcome when evidence is absent, stale, expired, unverified, mismatched, or needs correction but no severe red flag is established;
- use the escalation outcome for confirmed sanctions, confirmed PEP, suspected shell activity, or another explicitly severe/high-risk condition in the task evidence.

Do not copy `review_status` as the decision. An `in_review` record can satisfy the evidence test, and an `approved` record can still fail current bank, tax, license, or risk controls.

Populate review/follow-up lists from the template's description: include every ID whose current evidence prevents unconditional release. Set an overall-ready flag true only when every scoped ID can be released.

## Account-change release

For each ticket, join the business to current compliance details and the ticket's vendor ID. Recompute every control from current evidence:

- requested bank account exists and matches the current vendor bank record where required;
- bank status is usable, not closed or name-mismatched;
- compliance and vendor tax identifiers are present, valid, and consistent;
- license is valid on the review date;
- required documents are complete;
- sanctions and PEP screening have been run and do not establish a confirmed adverse result;
- vendor is not on hold/inactive;
- shell-company and task-specific risk overrides are clear.

Any failed release control prevents `release`. Apply the template's `hold` versus `escalate` distinction from the severity mapping above. Report all requested override and exception lists independently of the final per-ID decision.
