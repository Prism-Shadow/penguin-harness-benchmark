---
name: trace-authoritative-work-item-scope
description: Establish an authoritative work-item population, lifecycle boundary, primary-record status, and duplicate/cancelled provenance for portfolio analytics.
version: 2026-11-15
---

# Authoritative work-item scope

Use this before any count, percentage, or readiness computation.

## Inputs and prerequisites

- The task contract, the public `work_items` fields, and any scope identifier/target row.
- Treat `work_items.status`, `work_type`, `team`, `product_area`, lifecycle dates, `duplicate_of`, `release_id`, and `milestone_id` as authoritative.
- Treat `mirror_status` and `legacy_category` as stale presentation fields unless the task explicitly says otherwise.

## Procedure

1. Translate the contract into exact equality filters for scope values. Do not infer team or product membership from an id prefix or title.
2. For a quarter, use a half-open close interval: first day inclusive through the first day of the next quarter exclusive. For an as-of window, exclude activity after the as-of date.
3. Distinguish active records from completed records by authoritative status. Preserve the contract's completion set; do not treat every non-null `closed_at` as a completed business status.
4. Build the primary population by excluding `status = Duplicate`, `status = Cancelled`, and records with a non-null `duplicate_of`. Do not let an apparently closed duplicate back into the denominator.
5. Reconcile duplicate provenance separately: group excluded duplicate ids under their non-null `duplicate_of` value and report the cluster without counting duplicates as primary work.
6. Keep boundary cases visible: compare dates as ISO dates, use `<` for a still-overdue test and `<=` only where the contract calls for inclusion. A due date equal to the as-of date is not past due.
7. Re-run a count by category/status after filtering and confirm the total equals the sum of its parts. Retain a compact query result as the verification basis.

## Output check

- Every reported id is unique and satisfies the contract.
- Primary ids and excluded ids are disjoint.
- Stale mirror/legacy fields never determine inclusion or completion.
