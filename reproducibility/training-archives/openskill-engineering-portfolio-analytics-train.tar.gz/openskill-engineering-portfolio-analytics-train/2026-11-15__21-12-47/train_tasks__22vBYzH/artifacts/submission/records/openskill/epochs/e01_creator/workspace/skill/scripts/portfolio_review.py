#!/usr/bin/env python3
"""Read-only, exact-arithmetic helper for the portfolio review Skill library."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Iterable, Sequence


COMPLETE_STATUSES = {"Closed", "Done", "Deployed", "Verified"}
OPEN_STATUSES = {"Backlog", "In Progress", "Review", "Reopened"}
CATEGORY_ORDER = ("NewFeature", "TechDebt", "Reliability", "Security")
CATEGORY_BY_WORK_TYPE = {
    "Feature": "NewFeature",
    "Enhancement": "NewFeature",
    "Chore": "TechDebt",
    "Refactor": "TechDebt",
    "Dependency": "TechDebt",
    "Bug": "Reliability",
    "Incident": "Reliability",
    "Reliability": "Reliability",
    "Security": "Security",
    "Compliance": "Security",
}
TARGET_COLUMN = {
    "NewFeature": "new_feature_pct",
    "TechDebt": "tech_debt_pct",
    "Reliability": "reliability_pct",
    "Security": "security_pct",
}
SEVERITY_RANK = {"S1": 1, "S2": 2, "S3": 3, "S4": 4}
BLOCKER_SEVERITY_RANK = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}


class ReviewError(RuntimeError):
    """Raised when public inputs are insufficient or internally inconsistent."""


@dataclass(frozen=True)
class Fixed:
    """A Decimal with a required JSON display precision."""

    value: Decimal
    places: int


def fixed(value: Decimal | int | str, places: int) -> Fixed:
    quantum = Decimal(1).scaleb(-places)
    rounded = Decimal(value).quantize(quantum, rounding=ROUND_HALF_UP)
    if rounded == 0:
        rounded = abs(rounded)
    return Fixed(rounded, places)


def divide_ratio(numerator: int, denominator: int) -> Decimal:
    if denominator == 0:
        return Decimal(0)
    return Decimal(numerator) / Decimal(denominator)


def percentage(count: int, denominator: int) -> Decimal:
    if denominator == 0:
        return Decimal(0)
    return Decimal(count) * Decimal(100) / Decimal(denominator)


def render_json(value: Any, indent: int = 2) -> str:
    """Render JSON while preserving exact fractional digits for Fixed values."""

    replacements: dict[str, str] = {}

    def prepare(item: Any) -> Any:
        if isinstance(item, Fixed):
            token = f"__PORTFOLIO_FIXED_{len(replacements):06d}__"
            replacements[token] = format(item.value, f".{item.places}f")
            return token
        if isinstance(item, dict):
            return {key: prepare(child) for key, child in item.items()}
        if isinstance(item, (list, tuple)):
            return [prepare(child) for child in item]
        return item

    rendered = json.dumps(prepare(value), indent=indent, ensure_ascii=False)
    for token, literal in replacements.items():
        rendered = rendered.replace(json.dumps(token), literal)
    return rendered + "\n"


def write_json(path: str, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_json(value), encoding="utf-8")


def parse_date(value: str | None, field: str) -> date | None:
    if value is None or value == "":
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ReviewError(f"{field} is not an ISO date: {value!r}") from exc


def quarter_bounds(quarter: str) -> tuple[date, date]:
    match = re.fullmatch(r"(\d{4})-Q([1-4])", quarter)
    if not match:
        raise ReviewError(f"quarter must look like YYYY-QN, got {quarter!r}")
    year, q = int(match.group(1)), int(match.group(2))
    start_month = 3 * (q - 1) + 1
    end_month = start_month + 3
    start = date(year, start_month, 1)
    end = date(year + 1, 1, 1) if end_month == 13 else date(year, end_month, 1)
    return start, end


def is_duplicate(item: dict[str, Any]) -> bool:
    return item.get("status") == "Duplicate" or item.get("duplicate_of") is not None


def is_complete(item: dict[str, Any]) -> bool:
    return item.get("status") in COMPLETE_STATUSES


def is_cancelled(item: dict[str, Any]) -> bool:
    return item.get("status") == "Cancelled"


def category_of(item: dict[str, Any]) -> str:
    work_type = item.get("work_type")
    category = CATEGORY_BY_WORK_TYPE.get(work_type)
    if category:
        return category
    raise ReviewError(
        f"unknown authoritative work_type {work_type!r} for {item.get('id')}; "
        "resolve it from an unambiguous label or title rather than guessing"
    )


def owner_label(owner: str | None) -> str:
    return "UNASSIGNED" if owner is None or str(owner).strip() == "" else str(owner)


class APIClient:
    def __init__(self, base_url: str, token: str, case: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.case = case
        self.entries: list[dict[str, Any]] = []

    def query(self, purpose: str, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
        payload = json.dumps({"sql": sql, "params": list(params)}).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url}/api/query",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-Env-Token": self.token,
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise ReviewError(f"query failed ({exc.code}) for {purpose}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise ReviewError(f"query failed for {purpose}: {exc}") from exc

        columns = result["columns"]
        rows = result["rows"]
        if len(columns) != len(rows[0]) if rows else False:
            raise ReviewError("API returned inconsistent column/row widths")
        normalized_sql = " ".join(sql.split())
        digest_source = json.dumps(rows, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        self.entries.append(
            {
                "case": self.case,
                "purpose": purpose,
                "method": "POST",
                "endpoint": "/api/query",
                "sql": normalized_sql,
                "params": list(params),
                "row_count": result.get("row_count", len(rows)),
                "result_sha256": hashlib.sha256(digest_source.encode("utf-8")).hexdigest(),
            }
        )
        return [dict(zip(columns, row)) for row in rows]

    def write_audit_fragment(self, path: str | None) -> None:
        if not path:
            return
        fragment = {
            "case": self.case,
            "base_url": self.base_url,
            "access": "read-only",
            "entries": self.entries,
        }
        write_json(path, fragment)


WORK_ITEM_SQL = """
SELECT id, title, work_type, status, team, owner, product_area,
       created_at, due_at, closed_at, severity, priority, labels,
       story_points, release_id, milestone_id, duplicate_of,
       mirror_status, legacy_category
FROM work_items
ORDER BY id
"""


def fetch_all_work_items(client: APIClient) -> list[dict[str, Any]]:
    return client.query("Load authoritative work-item fields", WORK_ITEM_SQL)


def target_fraction(value: Any) -> Decimal:
    return Decimal(str(value))


def id_closed_order(item: dict[str, Any]) -> tuple[str, str]:
    return (item.get("closed_at") or "9999-12-31", item["id"])


def mix_command(args: argparse.Namespace) -> dict[str, Any]:
    if len(set(args.teams)) != len(args.teams) or len(set(args.product_areas)) != len(args.product_areas):
        raise ReviewError("team and product-area inputs must be unique")
    start, end = quarter_bounds(args.quarter)
    client = APIClient(args.base_url, args.token, args.case_label or args.scope_id)
    work_items = fetch_all_work_items(client)
    target_rows = client.query(
        "Load requested mix target",
        """
        SELECT scope_id, quarter, team_group, product_area,
               new_feature_pct, tech_debt_pct, reliability_pct, security_pct
        FROM mix_targets
        WHERE scope_id = ?
        """,
        [args.scope_id],
    )
    if len(target_rows) != 1:
        raise ReviewError(f"expected exactly one mix target for {args.scope_id}, got {len(target_rows)}")
    target = target_rows[0]
    if target["quarter"] != args.quarter:
        raise ReviewError(
            f"target quarter {target['quarter']!r} disagrees with requested {args.quarter!r}"
        )
    for team in args.teams:
        if team not in str(target.get("team_group") or ""):
            raise ReviewError(f"team {team!r} is absent from target team_group")
    for area in args.product_areas:
        if area not in str(target.get("product_area") or ""):
            raise ReviewError(f"product area {area!r} is absent from target product_area")

    team_set = set(args.teams)
    area_set = set(args.product_areas)
    candidates: list[dict[str, Any]] = []
    for item in work_items:
        closed = parse_date(item.get("closed_at"), f"closed_at for {item.get('id')}")
        if (
            item.get("team") in team_set
            and item.get("product_area") in area_set
            and closed is not None
            and start <= closed < end
        ):
            candidates.append(item)

    duplicate_rows = [item for item in candidates if is_duplicate(item)]
    cancelled_rows = [item for item in candidates if is_cancelled(item)]
    included = [
        item for item in candidates if not is_duplicate(item) and not is_cancelled(item) and is_complete(item)
    ]
    if len({item["id"] for item in included}) != len(included):
        raise ReviewError("included work-item IDs are not unique")
    if any(not is_complete(item) for item in included):
        raise ReviewError("non-complete item reached the closed mix")

    included.sort(key=id_closed_order)
    counts = Counter(category_of(item) for item in included)
    total = len(included)
    actual: dict[str, Fixed] = {}
    targets: dict[str, Fixed] = {}
    gaps: dict[str, Fixed] = {}
    for category in CATEGORY_ORDER:
        actual[category] = fixed(percentage(counts[category], total), 1)
        targets[category] = fixed(target_fraction(target[TARGET_COLUMN[category]]) * Decimal(100), 1)
        gaps[category] = fixed(actual[category].value - targets[category].value, 1)

    negative = sorted(
        [category for category in CATEGORY_ORDER if gaps[category].value < 0],
        key=lambda category: (
            gaps[category].value,
            -targets[category].value,
            CATEGORY_ORDER.index(category),
        ),
    )
    primary_category = negative[0] if negative else None
    secondary_category = negative[1] if len(negative) > 1 else None
    if primary_category is None:
        action = "MAINTAIN_CURRENT_MIX"
        rationale = "NO_NEGATIVE_GAPS"
    else:
        action = "REBALANCE_CAPACITY"
        rationale = "LARGEST_NEGATIVE_GAP"

    duplicate_ids = sorted({item["id"] for item in duplicate_rows}, key=lambda item_id: next(
        ((item.get("closed_at") or "9999-12-31"), item["id"]) for item in duplicate_rows if item["id"] == item_id
    ))
    cancelled_ids = sorted({item["id"] for item in cancelled_rows}, key=lambda item_id: next(
        ((item.get("closed_at") or "9999-12-31"), item["id"]) for item in cancelled_rows if item["id"] == item_id
    ))

    if args.shape == "mix-scope":
        output: dict[str, Any] = {
            "scope": {
                "scope_id": args.scope_id,
                "quarter": args.quarter,
                "teams": sorted(args.teams),
                "product_areas": sorted(args.product_areas),
                "target_scope_id": args.scope_id,
                "total_included": total,
            },
            "included_work_item_ids": [item["id"] for item in included],
            "category_counts": {category: counts[category] for category in CATEGORY_ORDER},
            "category_percentages": {category: actual[category] for category in CATEGORY_ORDER},
            "gap_table": [
                {
                    "category": category,
                    "target_pct": targets[category],
                    "actual_pct": actual[category],
                    "gap_pct": gaps[category],
                }
                for category in CATEGORY_ORDER
            ],
            "under_invested_categories": negative,
            "follow_up_action": {
                "action": action,
                "primary_category": primary_category,
                "secondary_category": secondary_category,
                "rationale_code": rationale,
            },
            "exclusion_flags": {
                "excluded_duplicate_ids": duplicate_ids,
                "excluded_cancelled_ids": cancelled_ids,
                "ignored_mirror_status_and_legacy_category": True,
            },
        }
    else:
        if primary_category is None:
            deficit_category = max(
                CATEGORY_ORDER,
                key=lambda category: (gaps[category].value, -CATEGORY_ORDER.index(category)),
            )
        else:
            deficit_category = primary_category
        per_team_counts = {team: 0 for team in args.teams}
        per_team_totals = {team: 0 for team in args.teams}
        for item in included:
            per_team_totals[item["team"]] += 1
            if category_of(item) == deficit_category:
                per_team_counts[item["team"]] += 1
        team_order = {team: index for index, team in enumerate(args.teams)}
        owner_team = min(
            args.teams,
            key=lambda team: (
                per_team_counts[team],
                divide_ratio(per_team_counts[team], per_team_totals[team]),
                team_order[team],
            ),
        )
        teams_output = sorted(args.teams) if args.team_order == "alphabetical" else list(args.teams)
        distractor_ids = sorted(
            {item["id"] for item in duplicate_rows + cancelled_rows},
            key=lambda item_id: next(
                ((item.get("closed_at") or "9999-12-31"), item["id"])
                for item in duplicate_rows + cancelled_rows
                if item["id"] == item_id
            ),
        )
        output = {
            "scope_id": args.scope_id,
            "quarter": args.quarter,
            "teams": teams_output,
            "product_area": args.product_areas[0],
            "included_work_item_ids": [item["id"] for item in included],
            "category_counts": {category: counts[category] for category in CATEGORY_ORDER},
            "mix_table": [
                {
                    "category": category,
                    "count": counts[category],
                    "actual_pct": actual[category],
                    "target_pct": targets[category],
                    "gap_pct": gaps[category],
                }
                for category in CATEGORY_ORDER
            ],
            "largest_deficit_category": deficit_category,
            "recommended_action": {
                "action": "REBALANCE_CAPACITY",
                "category": deficit_category,
                "owner_team": owner_team,
            },
            "excluded_distractor_ids": distractor_ids,
        }

    client.write_audit_fragment(args.audit_fragment)
    write_json(args.output, output)
    return output


def temporal_sla_candidate(item: dict[str, Any], as_of: date, window_start: date) -> bool:
    created = parse_date(item.get("created_at"), f"created_at for {item.get('id')}")
    if created is None or created > as_of:
        return False
    closed = parse_date(item.get("closed_at"), f"closed_at for {item.get('id')}")
    if is_complete(item):
        return closed is not None and window_start <= closed <= as_of
    if is_cancelled(item):
        return False
    if is_duplicate(item):
        return closed is None or window_start <= closed <= as_of
    return closed is None


def aging_bucket(days: int) -> str:
    if 0 <= days <= 3:
        return "0-3"
    if 4 <= days <= 7:
        return "4-7"
    if 8 <= days <= 14:
        return "8-14"
    if 15 <= days <= 30:
        return "15-30"
    return "31+"


def escalation_key(item: dict[str, Any]) -> tuple[Any, ...]:
    severity = str(item.get("severity") or "")
    priority = item.get("priority")
    due = item.get("due_at")
    return (
        SEVERITY_RANK.get(severity, 99),
        priority is None,
        priority if priority is not None else 10**9,
        due is None,
        due or "9999-12-31",
        item["id"],
    )


def duplicate_clusters(reportable: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, set[str]] = defaultdict(set)
    for item in reportable:
        if item.get("duplicate_of"):
            grouped[str(item["duplicate_of"])].add(item["id"])
    return [
        {"primary_id": primary_id, "duplicate_ids": sorted(duplicate_ids)}
        for primary_id, duplicate_ids in sorted(grouped.items())
    ]


def sla_command(args: argparse.Namespace) -> dict[str, Any]:
    as_of = parse_date(args.as_of, "--as-of")
    if as_of is None:
        raise ReviewError("--as-of is required")
    if args.window_days < 0:
        raise ReviewError("--window-days must be non-negative")
    window_start = as_of - timedelta(days=args.window_days)
    client = APIClient(args.base_url, args.token, args.case_label)
    work_items = fetch_all_work_items(client)
    client.query(
        "Load authoritative SLA policy reference",
        "SELECT severity, days_to_due FROM sla_policy ORDER BY severity",
    )

    teams = set(args.teams)
    categories = set(args.categories)
    scoped: list[dict[str, Any]] = []
    for item in work_items:
        if item.get("team") not in teams:
            continue
        try:
            category = category_of(item)
        except ReviewError:
            continue
        if category not in categories:
            continue
        if temporal_sla_candidate(item, as_of, window_start):
            scoped.append(item)

    reportable_duplicates = [item for item in scoped if is_duplicate(item)]
    included = [item for item in scoped if not is_duplicate(item) and not is_cancelled(item)]
    if len({item["id"] for item in included}) != len(included):
        raise ReviewError("primary SLA IDs are not unique")
    included.sort(key=lambda item: item["id"])

    overdue: list[dict[str, Any]] = []
    overdue_details: list[tuple[dict[str, Any], int]] = []
    for item in included:
        due = parse_date(item.get("due_at"), f"due_at for {item.get('id')}")
        if due is None:
            continue
        effective_end = parse_date(item.get("closed_at"), f"closed_at for {item.get('id')}") if is_complete(item) else as_of
        if effective_end is None:
            raise ReviewError(f"completed item {item['id']} lacks closed_at")
        age_days = (effective_end - due).days
        if age_days > 0:
            overdue.append(item)
            overdue_details.append((item, age_days))

    overdue.sort(key=lambda item: item["id"])
    missing_owner_ids = [item["id"] for item in included if owner_label(item.get("owner")) == "UNASSIGNED"]
    duplicate_groups = duplicate_clusters(reportable_duplicates)
    breach_rate = fixed(divide_ratio(len(overdue), len(included)), 3)

    scope = {
        "teams": sorted(args.teams),
        "as_of": as_of.isoformat(),
        "recent_closed_window_days": args.window_days,
    }
    if args.shape == "sla-buckets":
        buckets = {bucket: 0 for bucket in ("0-3", "4-7", "8-14", "15-30", "31+")}
        for _, age_days in overdue_details:
            buckets[aging_bucket(age_days)] += 1
        team_counts = Counter(item["team"] for item in overdue)
        hotspot_counts = Counter((item["team"], owner_label(item.get("owner"))) for item in overdue)
        if hotspot_counts:
            top_team, top_owner = sorted(
                hotspot_counts,
                key=lambda pair: (-hotspot_counts[pair], pair[0], pair[1]),
            )[0]
            top_count = hotspot_counts[(top_team, top_owner)]
        else:
            top_team, top_owner, top_count = sorted(args.teams)[0], "UNASSIGNED", 0
        scope["sla_categories"] = list(args.categories)
        output = {
            "task_id": args.case_label,
            "scope": scope,
            "included_primary_ids": [item["id"] for item in included],
            "overdue_primary_ids": [item["id"] for item in overdue],
            "aging_bucket_counts": buckets,
            "team_overdue_counts": [
                {"team": team, "overdue_count": team_counts[team]} for team in sorted(args.teams)
            ],
            "top_hotspot": {"team": top_team, "owner": top_owner, "overdue_count": top_count},
            "duplicate_clusters": duplicate_groups,
            "missing_owner_ids": missing_owner_ids,
            "breach_rate": breach_rate,
        }
    else:
        severity_counts = {severity: 0 for severity in ("S1", "S2", "S3", "S4")}
        for item in overdue:
            if item.get("severity") not in severity_counts:
                raise ReviewError(f"unexpected severity {item.get('severity')!r} for {item['id']}")
            severity_counts[item["severity"]] += 1
        scope["categories"] = list(args.categories)
        output = {
            "scope": scope,
            "included_primary_ids": [item["id"] for item in included],
            "overdue_primary_ids": [item["id"] for item in overdue],
            "overdue_counts_by_severity": severity_counts,
            "escalation_queue_ids": [item["id"] for item in sorted(overdue, key=escalation_key)],
            "missing_owner_ids": missing_owner_ids,
            "duplicate_clusters": duplicate_groups,
            "sla_breach_rate": breach_rate,
        }

    client.write_audit_fragment(args.audit_fragment)
    write_json(args.output, output)
    return output


def release_command(args: argparse.Namespace) -> dict[str, Any]:
    client = APIClient(args.base_url, args.token, args.case_label or args.release_id)
    release_rows = client.query(
        "Load target release",
        "SELECT id, name, target_date, train FROM releases WHERE id = ?",
        [args.release_id],
    )
    if len(release_rows) != 1:
        raise ReviewError(f"expected exactly one release for {args.release_id}, got {len(release_rows)}")
    milestones = client.query(
        "Load target release milestones",
        "SELECT id, release_id, name, owner_team FROM milestones WHERE release_id = ? ORDER BY id",
        [args.release_id],
    )
    blockers = client.query(
        "Load target release blockers",
        "SELECT id, work_item_id, release_id, severity, cause, status, opened_at, resolved_at "
        "FROM blockers WHERE release_id = ? ORDER BY id",
        [args.release_id],
    )
    dependency_rows = client.query(
        "Load dependency graph",
        "SELECT blocked_id, depends_on_id, relation FROM dependencies ORDER BY blocked_id, depends_on_id, relation",
    )
    work_items = fetch_all_work_items(client)

    by_id = {item["id"]: item for item in work_items}
    cohort = [item for item in work_items if item.get("release_id") == args.release_id]
    primary = [item for item in cohort if not is_duplicate(item) and not is_cancelled(item)]
    if len({item["id"] for item in primary}) != len(primary):
        raise ReviewError("primary release IDs are not unique")
    primary_ids = {item["id"] for item in primary}
    completed_ids = {item["id"] for item in primary if is_complete(item)}
    gating_ids = sorted(primary_ids - completed_ids)

    milestone_output: list[dict[str, Any]] = []
    for milestone in sorted(milestones, key=lambda item: item["id"]):
        members = [item for item in primary if item.get("milestone_id") == milestone["id"]]
        completed = sum(is_complete(item) for item in members)
        milestone_output.append(
            {
                "milestone_id": milestone["id"],
                "complete_primary": completed,
                "primary_total": len(members),
                "completion_pct": fixed(percentage(completed, len(members)), 1),
            }
        )

    readiness = fixed(divide_ratio(len(completed_ids), len(primary_ids)), 3)
    unresolved_high_impact = [
        blocker
        for blocker in blockers
        if blocker.get("severity") in {"Critical", "High"}
        and blocker.get("resolved_at") is None
        and blocker.get("status") != "Resolved"
    ]
    cause_counts = Counter(blocker["cause"] for blocker in unresolved_high_impact)
    blocker_output = {cause: cause_counts[cause] for cause in sorted(cause_counts)}

    graph: dict[str, list[str]] = defaultdict(list)
    for edge in dependency_rows:
        blocked, dependency = edge.get("blocked_id"), edge.get("depends_on_id")
        if blocked and dependency:
            graph[blocked].append(dependency)
    for node in graph:
        graph[node] = sorted(set(graph[node]))

    def node_is_complete(node: str) -> bool:
        node_item = by_id.get(node)
        return bool(node_item and is_complete(node_item))

    chains: set[tuple[str, ...]] = set()

    def walk(path: tuple[str, ...]) -> bool:
        node = path[-1]
        added_below = False
        for child in graph.get(node, []):
            if child in path:
                continue
            child_path = path + (child,)
            deeper = walk(child_path) if child in graph else False
            if not node_is_complete(child):
                if deeper:
                    added_below = True
                else:
                    chains.add(child_path)
                    added_below = True
            elif deeper:
                added_below = True
        return added_below

    for gating_id in gating_ids:
        walk((gating_id,))

    sorted_chains = [list(chain) for chain in sorted(chains)]
    has_critical_blocker = any(
        blocker.get("severity") == "Critical" for blocker in unresolved_high_impact
    )
    if has_critical_blocker or sorted_chains:
        ship_decision = "NO_SHIP"
    elif gating_ids or readiness.value < Decimal(1) or unresolved_high_impact:
        ship_decision = "SHIP_WITH_WATCH"
    else:
        ship_decision = "SHIP"

    output = {
        "release_id": args.release_id,
        "ship_decision": ship_decision,
        "milestone_completion": milestone_output,
        "gating_work_item_ids": gating_ids,
        "blocker_cause_counts": blocker_output,
        "critical_dependency_chains": sorted_chains,
        "readiness_score": readiness,
    }

    client.write_audit_fragment(args.audit_fragment)
    write_json(args.output, output)
    return output


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--base-url", default="http://127.0.0.1:9024")
    parser.add_argument("--token", default="portfolio-readonly")
    parser.add_argument("--case-label", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--audit-fragment")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    mix = subparsers.add_parser("mix", help="run a portfolio mix review")
    add_common(mix)
    mix.add_argument("--scope-id", required=True)
    mix.add_argument("--quarter", required=True)
    mix.add_argument("--teams", nargs="+", required=True)
    mix.add_argument("--product-areas", nargs="+", required=True)
    mix.add_argument("--shape", choices=("mix-scope", "mix-single"), required=True)
    mix.add_argument("--team-order", choices=("alphabetical", "given"), default="alphabetical")
    mix.set_defaults(handler=mix_command)

    sla = subparsers.add_parser("sla", help="run an SLA aging review")
    add_common(sla)
    sla.add_argument("--teams", nargs="+", required=True)
    sla.add_argument("--categories", nargs="+", required=True)
    sla.add_argument("--as-of", required=True)
    sla.add_argument("--window-days", type=int, required=True)
    sla.add_argument("--shape", choices=("sla-buckets", "sla-severity"), required=True)
    sla.set_defaults(handler=sla_command)

    release = subparsers.add_parser("release", help="run a release readiness review")
    add_common(release)
    release.add_argument("--release-id", required=True)
    release.set_defaults(handler=release_command)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        args.handler(args)
    except ReviewError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
