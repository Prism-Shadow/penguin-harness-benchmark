# Optimizer Meta Guidance After Epoch 2

## Accepted gains

- Exact placeholder scope and literal copying repaired the disposition-register regression.
- Plea/finding/count separation and consistent misdemeanor/pending labels produced a perfect register score.
- The financial exclusion distinction and no-restitution payment label materially improved both financial packets.
- Explicit return-date anchoring and signed local license terms improved the financial packet.

## Persistent failure pattern

- The same action can be dated correctly in one output section and incorrectly null in another. Corrections must be propagated across every repeated representation.
- Zero/absent financial items and unsupported proposed items use different exclusion concepts; actors still interchange them.

## Next-edit strategy

- Add a cross-field propagation check for repeated dates, statuses, identifiers, and amounts.
- Tighten the distinction between an item that is absent from the balance and a proposed item lacking order or policy support.
- Preserve exact placeholder text and template null permissions while making these changes.
