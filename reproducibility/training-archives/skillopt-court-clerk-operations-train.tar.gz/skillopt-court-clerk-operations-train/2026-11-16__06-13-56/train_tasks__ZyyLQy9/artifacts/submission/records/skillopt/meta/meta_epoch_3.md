# Optimizer Meta Guidance After Epoch 3

## Accepted evidence

- The epoch-2 slow guidance is the strongest retained state at `0.911111` selection mean.
- Paired comparison shows it repairs the prior large failures while preserving the traffic success.

## Rejected directions

- Adding granular exclusion-cause taxonomy as a fast edit regressed the financial and disposition tasks.
- Adding additional literal-propagation language to the protected section regressed the traffic task.
- More prose is not monotonically helpful: over-specific instructions can displace the actor's use of the template's controlling vocabulary.

## Final-epoch strategy

- Do not carry rejected text forward.
- Make no semantic change unless a new, distinct, broadly reusable defect is evidenced in the final rollout.
- Preserve the accepted `v0.3.1` checkpoint as the best State if no strict improvement is demonstrated.
