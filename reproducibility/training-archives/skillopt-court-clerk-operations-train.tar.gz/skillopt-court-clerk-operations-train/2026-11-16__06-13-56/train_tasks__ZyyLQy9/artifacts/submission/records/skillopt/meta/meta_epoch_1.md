# Optimizer Meta Guidance After Epoch 1

## Productive changes

- Field-scoped record authority improved the financial-packet task and allowed a local six-month license term to replace a summary charge value.
- Requested installment selection plus deterministic remainder math substantially improved the previously low-scoring field packet.
- Misdemeanor-specific departure labels repaired one visible disposition error.

## Regressions from over-broad instructions

- A broad exhaustive-placeholder instruction caused actors to shorten the required literal placeholder in one task and to import unrelated office details into another task's case-level missing-field list.
- A financial rule must state the no-restitution branch explicitly; otherwise an actor can use the restitution-priority label when no restitution exists.

## Next-edit strategy

- Retain the field-authority and remainder-math edits.
- Narrow placeholder collection to fields represented by the current template structure or explicitly declared missing for that structure, and demand byte-for-byte placeholder copying.
- Add an explicit no-restitution payment-application rule and compute return-to-court dates from the policy anchor only after the final installment date is known.
