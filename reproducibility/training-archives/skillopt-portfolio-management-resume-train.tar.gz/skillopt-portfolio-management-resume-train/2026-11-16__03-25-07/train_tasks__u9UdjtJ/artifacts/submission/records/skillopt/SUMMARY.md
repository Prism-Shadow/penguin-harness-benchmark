# SkillOpt training summary

- Method: `skillopt`; model `deepseek-flash`; reasoning effort `max`; 4 epochs on all five Train tasks.
- Selection: `train_all`; fixed comparison set: `train_001` through `train_005`.
- Initial mean: `0.6125942`.
- Retained best mean: `0.7946456` (`train_001` 1.0, `train_002` 0.846154, `train_003` 0.941176, `train_004` 0.416667, `train_005` 0.769231).
- Retained checkpoint: `epoch_3_fast_step`; snapshot digest `760b39b55a25787e6b238d43d1fa3942fd6de97802cf630d78c01817baac8d67`.
- Epochs 2–4 each ran previous and current epoch-end snapshots on the full fixed comparison set; see `epoch_comparisons.json` and `epochs/epoch_*.json`.
- Epoch-4 fast and slow candidates both tied `0.7946456` and were rejected under the strict-improvement gate.
- Final answers are copied from the retained checkpoint’s evaluated selection records; see `final_export.json` for hashes and source records.
- Exact delegated Actor usage is in `usage.json`; raw events and results remain under `runs/`, with judge feedback under `feedback/`.
