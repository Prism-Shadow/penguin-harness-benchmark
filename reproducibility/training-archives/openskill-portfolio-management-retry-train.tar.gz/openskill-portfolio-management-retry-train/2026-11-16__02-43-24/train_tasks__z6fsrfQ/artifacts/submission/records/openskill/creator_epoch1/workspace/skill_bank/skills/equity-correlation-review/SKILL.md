---
name: equity-correlation-review
description: Calculate Asteria index correlations from monthly simple returns, apply live high/low thresholds, identify concentration and diversification pairs, and map findings to sleeve actions with deterministic pair ordering.
---

# Equity Correlation Review

## Applicability

Use for international equity reviews, multi-asset correlation sections, and any
task requiring monthly simple returns, Pearson correlations, extreme pairs,
concentration flags, or diversification candidates and actions.

Read `../asteria-data-contract/SKILL.md` first. Use the requested index universe,
review window, monthly levels, and live policy thresholds from the snapshot.

## Procedure

1. Select the index IDs stated in the request. Do not silently add every index in
   the service, and do not drop one because it is not currently held.
2. If the request supplies explicit level start/end dates, use them. If it says
   “current 12-month window,” use the active correlation policy's review-window
   dates. Confirm `indices` metadata agrees.
3. Sort each index's level records ascending by date and retain every level inside
   the inclusive window. Require both endpoint dates, unique dates, positive
   levels, and the same observation count for every index.
4. Form monthly simple returns only from consecutive levels:

   ```text
   r_t = level_t / level_{t-1} - 1
   ```

   A 12-level monthly window therefore has 11 return observations. Do not use log
   returns, monthly percentage changes from the first level, or forward returns.

5. Calculate the Pearson coefficient on the common return pairs:

   ```text
   r = sum((x_t - x_bar) * (y_t - y_bar))
       / sqrt(sum((x_t - x_bar)^2) * sum((y_t - y_bar)^2))
   ```

   This is arithmetic-mean/sample Pearson correlation; either `n`- or `n-1`
   normalization cancels when the covariance-like numerator and standard
   deviations are defined consistently. Use high-precision Decimal throughout.
6. Compare and rank with unrounded coefficients. Round only the emitted
   correlation to the template's declared places, normally three.
7. Build every unordered pair `i < j` from the sorted index ID list. Within a pair,
   order the two IDs alphabetically. Sort pair rows lexicographically by the pair
   tuple unless the template asks for another ordering.

The reusable calculator is:

```bash
python3 skill_bank/scripts/asteria_correlation.py \
  --snapshot snapshot.json \
  --index-ids IDX_A,IDX_B,IDX_C \
  --out correlations.json
```

It reads the active window and both thresholds from the policy when arguments are
not supplied.

## Extreme Pairs and Tie-Breaks

- `highest_positive` is the pair with the greatest exact coefficient. The label
  means the highest pair, not a filter to nonnegative coefficients.
- `lowest` is the pair with the least exact coefficient.
- If exact correlations tie, choose the lexicographically smaller pair tuple.
- Report the rounded coefficient in the output field; retain the exact value for
  ordering and diagnostics.
- A negative lowest pair is useful diversification evidence, not an error.

## Threshold Logic

Read `correlation_high_threshold` and `correlation_low_threshold` at run time. Use
inclusive tests unless the live policy explicitly says strict:

```text
high/concentration breach: r >= correlation_high_threshold
low/diversifying:          r <= correlation_low_threshold
```

- `high_threshold_breached` is true if any requested pair meets the high test.
- `china_asia_dependence_flag` is true when the exact pair
  `["IDX_CHINA", "IDX_AC_ASIA_PAC_EX_JP"]` meets the high test. Treat a missing
  member as not applicable rather than inventing a level series.
- `primary_code` priority for the supplied template family:
  1. `CHINA_ASIA_DEPENDENCE` when its exact flag is true.
  2. `GLOBAL_DEVELOPED_OVERLAP` when no China-Asia flag holds but a high pair is
     wholly within the developed/global reference IDs such as `IDX_WORLD`,
     `IDX_ACWI_IMI`, and `IDX_EAFE`.
  3. `NO_MATERIAL_CONCENTRATION` otherwise.

Do not use the rounded coefficient for threshold tests.

## Diversification Candidates

Use the allowed candidate list in the template as the candidate pool. For each
candidate, calculate its mean exact correlation to every other index in the
requested universe. Include it in `diversification_candidates` when that mean is at
or below the live low threshold. Sort the result alphabetically and de-duplicate.

An alternative stricter test is “all its pairwise correlations are at or below the
low threshold.” If both are computed, keep the template's requested field tied to
one declared rule; do not mix universes or thresholds. The shared calculator emits
both the mean-based `low_candidates` and the universal test as diagnostics.

Do not list a high-correlation region merely because it is allowed by the enum, and
do not list both members of every pair that happens to include the true diversifier.

## Sleeve Actions

For a two-action correlation template:

1. Use the `primary_code` to identify the concentration sleeve. For
   `CHINA_ASIA_DEPENDENCE`, the source sleeve is the held China index.
2. Find the lowest exact correlation between a requested diversifier candidate and
   the concentration member, breaking ties by candidate ID. Prefer only candidates
   that satisfy the declared low-diversifier rule.
3. Map an index ID to its current holding sleeve through the live holdings record's
   `instrument_id -> sleeve` join. Use the holding's sleeve spelling, not a guessed
   region name.
4. Emit `trim` for the concentration sleeve and `add` for the diversifier sleeve.
   If the template asks for two actions, sort them ascending by `sleeve`.
5. Follow the template's allowed `target_index_id` values. If the source sleeve has
   no target action or no permitted diversifier, use a defensible monitor/hold pair
   only when those values are allowed, and state the fallback rule in practice
   notes.

When the committee template lacks a `sleeve` name, still map the pair role directly:
`highest_concentration` is the maximum exact pair and `best_diversifier` is the
minimum exact pair. Keep those roles in that item order.

## Output Checks

- `index_set` is alphabetically sorted and contains exactly the requested IDs.
- `review_window` reports the actual first and last level dates used and
  `return_observations == level_count - 1`.
- Every pair list has two IDs in alphabetical order.
- Extreme pair selection used exact coefficients; displayed correlations use the
  declared precision.
- Concentration booleans follow inclusive live thresholds and exact pair identity.
- Diversification candidates and sleeve actions use the required order and only
  allowed enum values.
- No unrelated index IDs appear in pairs, candidates, or actions.

## Pitfalls

- Treating the 12 index levels as 12 returns.
- Calculating returns across non-consecutive or unsorted dates.
- Mixing level windows between indices or using levels outside the stated window.
- Using price levels directly as correlation inputs instead of simple returns.
- Parsing levels as binary floats and then comparing near a threshold.
- Sorting the pair alphabetically on only one side, or joining pair IDs into a
  string that loses order.
- Testing thresholds on the displayed three-decimal number instead of the exact
  coefficient.
- Choosing the other member of a low pair as the diversifier when its overall
  correlation profile is high.
- Calling a positive high correlation a diversification benefit.

