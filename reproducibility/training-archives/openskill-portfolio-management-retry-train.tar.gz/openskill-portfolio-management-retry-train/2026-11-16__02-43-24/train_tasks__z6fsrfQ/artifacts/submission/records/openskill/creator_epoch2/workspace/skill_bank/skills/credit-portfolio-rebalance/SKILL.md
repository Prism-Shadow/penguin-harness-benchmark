---
name: credit-portfolio-rebalance
description: Build or rotate Asteria fixed-income positions with exact post-trade market value, high-yield, duration, yield, issuer, subsector, and watchlist checks; revalidate explicit candidate shortlists before widening the BUY universe; distinguish non-negotiable constraints from carry or risk-reduction ranking.
---

# Credit Portfolio Rebalance

## Applicability

Use for:

- Buy-only energy-credit carry packages with a fixed ticket count and notional.
- Fixed-income rotations that reduce HY, duration, issuer, or watchlist pressure.
- Any task requiring post-trade market value, HY percentage, weighted modified
  duration, weighted yield to maturity, or credit constraint booleans.

Read `../asteria-data-contract/SKILL.md` first. Portfolio, policy, holdings, bond,
issuer, and watchlist facts must come from one live snapshot.

## Establish Before Selecting

From the request:

- Portfolio ID and allowed actions.
- Exact ticket count, total notional, equal/custom split, and external-cash flag.
- Eligibility scope: candidate flag, energy link, sector, rating bucket, or theme.
- Any explicit candidate shortlist, including a prior-week shortlist embedded in a
  meeting memo, together with its stated reason for preferring those names.
- Required carries, risk reduction, watchlist treatment, and output order.

From the live portfolio and policy:

- Current holdings and quantities in USD millions.
- `constraint_policy_id` and that policy's duration band, HY cap, target HY
  reduction, issuer limit, and subsector diversification minimum.
- Bond analytics, rating bucket, issuer ID, subsector, candidate flag, and energy
  flag.
- Issuer-level `watchlist` boolean.

## Exact Post-Trade Formulas

Let `q_i` be the post-trade quantity of instrument `i` in USD millions, `d_i` its
modified duration in years, and `y_i` its yield to maturity in percent.

```text
V = sum_i q_i
HY quantity = sum_{i: rating_bucket == HY} q_i
HY allocation percent = 100 * HY quantity / V
Weighted modified duration = sum_i(q_i * d_i) / V
Weighted YTM percent = sum_i(q_i * y_i) / V
Watchlist exposure = sum_{i: issuer.watchlist == true} q_i
Issuer share percent = 100 * sum_{i in issuer} q_i / V
HY reduction percentage points = pre_trade_HY_percent - post_trade_HY_percent
```

For a BUY, add its quantity; for a SELL, subtract it. A buy-only mandate increases
`V` by total buy notional. A cash-funded rotation keeps `V` unchanged and must
satisfy:

```text
sum_sells quantity = sum_buys quantity
```

unless the task explicitly supplies net external cash. Reject negative end
positions and duplicate or missing instrument IDs.

## Hard Constraints Versus Objective

Hard constraints are checked first and are not traded off against yield:

1. Allowed action, exact ticket count, exact total notional, and split rule.
2. Buy instruments must be current eligible candidates in the requested scope.
3. No BUY whose issuer is currently watchlisted when watchlist avoidance is
   required.
4. Post-trade HY allocation at or below the live policy cap.
5. Post-trade modified duration inside the live inclusive duration band.
6. Required HY reduction met as a percentage-point floor.
7. Required watchlist exposure cleared or reduced to the stated target.
8. Required issuer and subsector diversification rules.
9. Cash balance for a rotation and nonnegative positions.

Use the unrounded values for every comparison. A value exactly on a cap or band
edge passes when the policy wording is “maximum” or inclusive range.

### Selected-Issuer Interpretation

Some answer templates ask for `selected_issuer_diversification_pass`, not a full
portfolio issuer-concentration metric. For that field:

- Require selected BUY tickets to use distinct issuers when more than one ticket
  is requested.
- Treat new-money quantity by selected issuer divided by post-trade `V` as the
  selected-position share; compare it to the live issuer limit if the template
  ties the field to that limit.
- Compute the literal portfolio-wide maximum issuer share as a diagnostic when
  useful, but do not silently claim a legacy issuer pole was created by the new
  trade.

If the task instead explicitly asks for portfolio-wide issuer compliance, all
issuer shares must satisfy the cap. If the existing portfolio already breaches it,
report the pre-existing breach; a small new ticket cannot cure it on its own.

### Subsector Interpretation

Count distinct `subsector` values across selected BUY instruments. The selected
subsector check passes when that count is at least the live
`subsector_min_count_for_diversified`. For a two-ticket package this normally
means the tickets must not share one subsector.

## Watchlist Rule

Resolve every bond to its issuer record. The issuer boolean is authoritative.

- A buy-only package must exclude watchlisted issuers when the desk is sensitive
  to headline carry traps.
- A risk-reduction rotation may sell watchlisted holdings; selling is permitted
  and normally required to clear pressure.
- Sell the full relevant quantity when the required post-trade watchlist exposure
  is zero. A partial sale is valid only when quantity arithmetic still clears the
  requested target.
- Recompute exposure after every trade; do not rely on a stale memo quantity.

## Explicit Candidate Shortlists

A request may provide a field such as `candidate_shortlist`,
`candidate_shortlist_from_prior_week`, or a narrative list of preferred buys. Treat
that list as a preference ordering candidate universe, not as current eligibility
evidence. Revalidate every named instrument against the current snapshot before it
can enter a package:

1. Resolve the exact `instrument_id` in the current bond security master. An
   unknown, retired, or renamed ID is ineligible until a current record resolves it.
2. Require the current `candidate` flag to be true. A prior shortlist does not
   override a current false flag.
3. Resolve `issuer_id` in the current issuer master and, for a BUY, require
   `watchlist == false` whenever watchlist avoidance is mandated. A stale memo
   label such as “concern” or an old clearance note is not authoritative.
4. Recheck the live `rating_bucket`, sector, subsector, energy link, maturity, and
   other requested scope. For a risk-reduction rotation, a currently HY or
   watchlisted shortlisted name does not become a compliant IG BUY merely because
   it appeared on the prior list.
5. Apply every live portfolio and policy constraint to the proposed post-trade
   package. Static name-level eligibility alone is insufficient: HY cap, duration
   band, target HY reduction, watchlist exposure, issuer/subsector limits, cash
   balance, ticket count, and notional must still pass.

Record a compact validation status for every shortlisted name: current eligible;
not in the master; current candidate flag false; issuer watchlisted; rating or
scope mismatch; or policy-feasibility failure. These are validation outcomes, not
new portfolio facts.

### Shortlist-First Selection and Fallback

- Form the preferred BUY universe from shortlisted names that pass all current
  name-level checks.
- Enumerate and rank compliant packages using only that preferred universe first.
- Search the wider eligible universe only when no compliant package can be formed
  from the shortlist after all required tickets, cash, and policy constraints are
  considered. Do not widen the search merely to improve carry, duration, theme, or
  another objective score when a shortlist-only package already passes the hard
  rules.
- When fallback is necessary, record the reason (for example, too few eligible
  shortlisted IG names, insufficient cash capacity, or no package satisfying the
  duration band) and identify which shortlisted names failed validation or
  feasibility. Select replacement names from the wider universe under the same
  hard constraints and objective ranking.
- Never use stale memo quantities, exception labels, or a stale shortlist comment
  as current holdings or analytics. Live quantities and instrument analytics always
  control sizing and metrics.

### Duration-Extension Preference

When the mandate explicitly asks to preserve duration, compare otherwise
equivalent compliant packages by signed duration extension:

```text
duration_extension = post_trade_weighted_modified_duration
                     - pre_trade_weighted_modified_duration
```

Prefer the lower signed value after hard feasibility and the primary objective are
equal. Then break ties by ascending instrument-ID tuple. This preference never
permits a package outside the policy duration band and never displaces a hard
constraint. When the mandate does not ask to preserve duration, retain the prior
absolute-duration-drift tie-break.

## Buy-Only Carry Workflow

1. If an explicit shortlist exists, revalidate it first and restrict the initial
   BUY universe to currently eligible shortlisted bonds. Otherwise use the stated
   scope. In both cases require current `candidate == true` and any requested
   eligibility attributes such as `energy_linked == true` or an allowed rating
   bucket.
2. Exclude BUY candidates whose issuer is watchlisted.
3. Enumerate combinations of exactly the requested number of tickets.
4. Apply equal or stated notional split and compute every post-trade formula.
5. Discard any combination failing a hard constraint.
6. Among feasible combinations, rank by descending post-trade weighted YTM when
   the stated objective is improved expected carry.
7. Break ties in this order: lower post-trade HY percentage, then the duration
   preference required by the mandate (lower signed extension when duration
   preservation is requested; otherwise smaller absolute drift), then the sorted
   instrument-ID tuple.
8. If the request imposes current theme relevance or client positioning, use that
   only after the hard filters and, unless the task makes it a constraint, after
   the carry objective.

The reusable enumerator is:

```bash
python3 skill_bank/scripts/asteria_credit.py packages \
  --snapshot snapshot.json --portfolio "$PORTFOLIO_ID" \
  --tickets "$TICKET_COUNT" --total-notional "$TOTAL_NOTIONAL" \
  --equal-split --energy-linked \
  --top 10 --out packages.json
```

`feasible_package_count > 1` is normal. The selected package is one member of the
feasible set under a declared objective; it is not proof of a unique security
choice. Record the selection rule in practice notes.

## Rotation Workflow

1. Start with live holdings and policy. Identify watchlisted holdings and HY
   holdings using the live masters.
2. Decide which existing positions are sale candidates; sells cannot exceed the
   current quantity.
3. Clear the required watchlist exposure first when the mandate says to remove it.
4. Find the minimum incremental HY quantity sale needed to satisfy both the HY cap
   and the target reduction, unless the task explicitly says to maximize reduction.
   When several HY positions can supply the same incremental quantity, sell the
   lower-YTM position first to minimize carry give-up; break a tie by higher
   modified duration, then instrument ID. This permits a partial sale exactly to
   the required risk level while retaining eligible carry.
5. Fund permitted BUY candidates with sale proceeds. For a risk-reduction rotation,
   IG candidates normally improve the HY metric; rank eligible buys by descending
   YTM subject to duration and any issuer/subsector rules. If a selected new-money
   issuer cap applies, fill that issuer only up to the permissible quantity and use
   the next-ranked eligible issuer for the remainder. When a shortlist exists, use
   currently eligible shortlisted names first and document any necessary fallback
   to the wider universe.
6. Recompute all post-trade metrics and every exception flag exactly.
7. Report one coherent trade set. If several equivalent packages exist, use
   smaller unnecessary turnover, then higher post-trade YTM, then the mandated
   duration preference, then action and instrument-ID order as the stable
   tie-break.

For a risk note enum, choose by the constraint that actually determines the
ticket set, in this order: HY cap pressure, watchlist concentration, duration
preservation, carry trade-off, no action. Do not label a package “no action” when
it changes holdings.

## Sales Positioning

When a template requests sales positioning:

- Derive target segment from the request's stated client context, not from a
  yield ranking.
- Derive energy theme from current positive/negative energy signals and the
  selected bonds' current `recommended_theme_tags`.
- If the package's main client benefit is avoiding higher-yield watchlist issuers,
  the watchlist-avoidance theme is appropriate even when no specific commodity
  tag is present.
- Use current signal direction; do not pitch an oil, LNG, midstream, transition,
  or carry theme contradicted by the live market record.

## Output Checks

- Trade action literals and order exactly match the template. Buy-only tasks often
  sort by instrument ID; rotations often sort SELL before BUY, then instrument ID.
- Quantities use the requested precision and units (normally USD millions).
- Total market value includes external new cash for a buy-only mandate; it stays
  unchanged for a cash-funded rotation.
- HY percent is quantity-weighted over post-trade `V`, not over the old base.
- Duration and YTM are quantity-weighted with current bond analytics.
- Issuer and subsector booleans use the interpretation required by the field
  names and live policy.
- Every claimed boolean is supported by the unrounded computed value.
- A watchlist-sell list is sorted as declared and contains only positions actually
  sold.
- Every shortlisted BUY candidate has a current-master validation status. If the
  final package uses names outside the shortlist, the fallback reason and failed
  shortlist alternatives are recorded outside the strict answer if the template has
  no field for them.

## Pitfalls

- Selecting the highest-yield bonds before removing watchlist issuers.
- Treating a prior-week shortlist as a current `candidate` flag, current rating, or
  current issuer-watchlist clearance.
- Widening beyond a shortlist when a compliant shortlist-only package already
  exists, or silently widening when it does not.
- Using a stale memo quantity or exception label instead of current holdings.
- Preferring lower duration extension ahead of any hard HY, duration-band,
  watchlist, cash, ticket, or policy constraint.
- Adding HY to a buy-only package without recomputing the post-trade HY percentage
  on the enlarged market value.
- Using the stale local market value or quantity after the live holdings differ.
- Treating issuer tags or notes as a replacement for the issuer watchlist flag.
- Summing yields without quantity weights, or summing market values with a price
  multiplier not defined by the service.
- Selling more than the holding, failing cash balance, or allowing a position to
  go negative after rounding.
- Confusing the live percentage-point reduction target with a relative-percent
  reduction of the pre-trade HY amount.
- Hiding package ambiguity. If multiple packages satisfy all hard rules, state the
  ranking rule and why the chosen package wins under it.

