#!/usr/bin/env python3
"""Shared utilities for portable Asteria Skill resources.

Only the Python standard library is used. Numeric API fields are parsed as
Decimal and serialized without first passing through binary floating point.
"""

from __future__ import annotations

import json
import os
import tempfile
import time
import urllib.error
import urllib.request
from decimal import Decimal, ROUND_HALF_UP, localcontext
from pathlib import Path
from typing import Any


class AsteriaError(RuntimeError):
    """Raised when an Asteria record or request is inconsistent."""


def as_decimal(value: Any) -> Decimal:
    """Return an exact Decimal for a JSON scalar or numeric string."""

    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool) or value is None:
        raise AsteriaError(f"Expected a numeric value, got {value!r}")
    return Decimal(str(value))


def _json_loads_exact(text: str) -> Any:
    return json.loads(text, parse_float=Decimal)


def load_json(path: str | os.PathLike[str]) -> Any:
    with open(path, "r", encoding="utf-8") as handle:
        return _json_loads_exact(handle.read())


def _encode_json(value: Any, level: int = 0) -> str:
    """Serialize JSON while preserving Decimal values as JSON numbers."""

    indent = "  " * level
    child_indent = "  " * (level + 1)
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise AsteriaError("Non-finite Decimal cannot be serialized as JSON")
        return format(value, "f")
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise AsteriaError("Non-finite float cannot be serialized as JSON")
        return repr(value)
    if isinstance(value, (list, tuple)):
        if not value:
            return "[]"
        rendered = [child_indent + _encode_json(item, level + 1) for item in value]
        return "[\n" + ",\n".join(rendered) + "\n" + indent + "]"
    if isinstance(value, dict):
        if not value:
            return "{}"
        rendered = []
        for key, item in value.items():
            if not isinstance(key, str):
                raise AsteriaError(f"JSON object key must be a string: {key!r}")
            rendered.append(
                child_indent
                + json.dumps(key, ensure_ascii=False)
                + ": "
                + _encode_json(item, level + 1)
            )
        return "{\n" + ",\n".join(rendered) + "\n" + indent + "}"
    raise AsteriaError(f"Unsupported JSON value type: {type(value).__name__}")


def write_json(path: str | os.PathLike[str], value: Any) -> None:
    """Write an exact JSON document atomically."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=target.name + ".", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(_encode_json(value))
            handle.write("\n")
        os.replace(temp_name, target)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def http_get_json(base_url: str, path: str, timeout: float = 15.0) -> Any:
    """GET a JSON endpoint with a small retry policy and no credentials."""

    url = base_url.rstrip("/") + "/" + path.lstrip("/")
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "asteria-skill/1.0",
        },
        method="GET",
    )
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read().decode("utf-8")
            return _json_loads_exact(body)
        except urllib.error.HTTPError as exc:
            last_error = exc
            if 400 <= exc.code < 500:
                break
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error = exc
        if attempt < 2:
            time.sleep(0.25 * (attempt + 1))
    raise AsteriaError(f"GET {url} failed: {last_error}")


def round_half_up(value: Any, places: int) -> Decimal:
    """Round to a declared number of decimal places using ROUND_HALF_UP."""

    number = as_decimal(value)
    quantum = Decimal(1).scaleb(-places)
    with localcontext() as context:
        context.prec = max(50, len(number.as_tuple().digits) + places + 10)
        return number.quantize(quantum, rounding=ROUND_HALF_UP)


def decimal_text(value: Any) -> str:
    """Return the exact decimal spelling used by the calculators."""

    return format(as_decimal(value), "f")
