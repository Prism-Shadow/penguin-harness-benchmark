# OpenSkill research notes — Asteria portfolio management

Construction date: 2026-11-15. Research bundle supplied by the bridge:
`/home/agent/.agents/skills/gdpevo-codex-bridge/research/`.

## Domain questions formed from the public inputs

1. How should an institutional portfolio be restored or rotated while respecting a stated policy, prices, and transaction constraints?
2. How should post-trade market value, high-yield share, duration, yield, and concentration be measured consistently?
3. How should monthly simple returns and Pearson correlations be computed over a supplied index-level window?
4. How should documented score thresholds be turned into active views, view changes, conviction, rationale codes, and a portfolio overlay?
5. When a local worksheet conflicts with the live book of record, which source controls?

## Retrieved knowledge used

### Allocation and rebalancing

Source: U.S. SEC Investor.gov, “Asset Allocation, Diversification, and Rebalancing”
https://www.investor.gov/additional-resources/general-resources/publications-research/info-sheets/beginners-guide-asset

Retrieved evidence: restoring a portfolio to an intended allocation can require sales and purchases and should account for transaction costs. The task's own stated prices, quantities, constraints, and policy thresholds remain the operative inputs. The source therefore supports a constrained, book-of-record rotation rather than a narrative recommendation detached from holdings.

### Exact decimal bookkeeping

Source: Python 3 documentation, `decimal` — exact decimal arithmetic
https://docs.python.org/3/library/decimal.html

Retrieved evidence: decimal arithmetic avoids binary floating-point representation surprises. The documented example is 2 units at 15 each equalling 30, which is 30% of a 100 portfolio. For this Skill, positions and dollar quantities are treated as exact decimal values when computing weights and post-trade metrics; rounding occurs only after the calculation and only to the output schema precision.

## Knowledge conclusions

- Current API records are the book of record. Local payload snapshots are intake context, scope declarations, and output contracts; they do not override current holdings, security-master fields, policy thresholds, or as-of dates.
- Policy thresholds and score mappings must be read from the service at run time, not hard-coded from this instance.
- Correlation is computed from consecutive monthly index levels as simple returns `level_t / level_{t-1} - 1`, then Pearson correlation over the common requested window.
- A portfolio metric is quantity-weighted using current USD-million quantities and current instrument analytics. A trade preserves total market value when sales and purchases are equal; a buy-only mandate increases it by the buy notional.
- Selection rules should be lexicographic and auditable: hard eligibility and policy constraints first, then the task's stated objective (carry, view alignment, diversification, or risk reduction).
- Negative correlations are valuable diversifiers; a high positive pair is a concentration warning. Threshold comparisons use the current policy values.

## Search accounting

Additional targeted searches used: 0 of 3. The supplied research bundle contained documented anchors sufficient for the method. No official score, reference answer, or judge output was used.
