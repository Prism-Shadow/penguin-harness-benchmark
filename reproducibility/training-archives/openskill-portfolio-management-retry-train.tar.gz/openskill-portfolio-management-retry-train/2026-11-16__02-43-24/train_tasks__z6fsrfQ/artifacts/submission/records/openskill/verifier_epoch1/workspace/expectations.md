# Pre-candidate verification expectations

This file was written before any file under
`/app/submission/records/openskill/creator_epoch1/workspace/answers/` was
inspected. It records the public contracts and independently derived anchors
that will be used to verify the five candidate practice answers.

## Evidence baseline

- Live API book date: `2026-05-29` (portfolio summaries, holdings, policies, and
  energy data all report this date).
- Allocation policy set: `POLICY_SET_2026_05`; view mapping policy:
  `POL_ALLOCATION_MAPPING`.
- Credit default policy: duration band `[3.0, 5.0]` years, maximum HY
  allocation `20.0%`, issuer concentration limit `12.0%`, and at least two
  subsectors for diversification.
- Credit risk-reduction policy: the same limits plus target HY reduction
  `4.0` percentage points.
- Correlation policy: high threshold `0.8`, low threshold `0.2`, review window
  `2025-05-30` through `2026-04-30`.
- Allocation view mapping: score `>= 0.35` is `OW`, score `<= -0.35` is `UW`,
  otherwise `N`; absolute score `>= 0.70` is `HIGH` conviction, `>= 0.35` is
  `MEDIUM`, otherwise `LOW`. `change` is the rank difference
  (`UP`, `DOWN`, or `UNCHANGED`) from the stated Q1 view in the Q2 prior-view
  record.
- Raw API responses used for anchors are retained under `raw/` with a SHA-256
  manifest.

## train_001 - PF-EN-ALTA energy-credit buys

### Contract

- Top-level object must contain `portfolio_id`, `as_of_date`, `trade_package`,
  `post_trade_metrics`, `constraint_checks`, `sales_positioning`, and
  `data_precedence` with the template's types and enums.
- `portfolio_id` is `PF-EN-ALTA`; `as_of_date` is `YYYY-MM-DD`.
- `trade_package` has exactly two items, sorted by ascending `instrument_id`.
  Each item has `action`, `instrument_id`, and numeric `notional_usd_m` at one
  decimal place. Exactly two `BUY` tickets of `4.0` each are required.
- Post-trade metric values are numbers at two decimal places; all five
  constraint flags are booleans. Sales target and theme must use their enums.
- `data_precedence` must use its enum. Public evidence creates a conflict: the
  local snapshot is `2026-05-10` and the live book is `2026-05-29`.

### Independent live anchors

- Current five holdings total `60.0` USD millions.
- Current HY is `BND_EASTERN_LNG_2029`, `5.0m`; HY allocation is
  `5/60 = 8.3333%` (rounds to `8.33`).
- Current quantity-weighted modified duration is `3.201666...` years (rounds
  to `3.20`).
- Current quantity-weighted yield to maturity is `5.584166...%` (rounds to
  `5.58`).
- After the mandated `8.0m` of buys, total market value is exactly `68.0m`.
  Post-trade HY percentage, duration, and YTM must be computed on that result.

### Hard checks and unresolved selection

- Both selected instruments must be current `candidate: true`,
  `energy_linked: true` bonds whose live issuer record has `watchlist: false`.
- The two selected instruments must have distinct issuer IDs and distinct
  subsectors. Their package must keep post-trade HY at or below `20%`, duration
  within `[3.0, 5.0]`, and improve quantity-weighted YTM over the current
  `5.584166...%` baseline.
- The publicly possible pairs are not unique. A compliant selection must be
  accepted on eligibility, trade-size, constraint, and arithmetic grounds; no
  unique pair will be invented.
- The local client context explicitly supports `multi_asset_income` as the
  sales target. Exact theme choice is not uniquely reduced by the public
  contract beyond its enum and compatibility with the selected bonds.

## train_002 - PF-INT-NEXVEN correlation review

### Contract

- Required top-level keys: `portfolio_id`, `review_window`, `index_set`,
  `extreme_pairs`, `concentration`, `diversification_candidates`,
  `sleeve_actions`.
- `portfolio_id` is `PF-INT-NEXVEN`. The review window is `2025-05-30` to
  `2026-04-30`, with exactly `11` return observations from 12 consecutive
  monthly levels.
- `index_set` is an ascending list of exactly the nine requested index IDs.
- Each extreme-pair object has a two-ID alphabetical `pair_id` and a
  three-decimal correlation.
- `concentration` has boolean `china_asia_dependence_flag`, a permitted
  `primary_code`, and boolean `high_threshold_breached`.
- `diversification_candidates` uses the permitted IDs in ascending order.
  `sleeve_actions` has exactly two objects, sorted by `sleeve`, with allowed
  actions and target IDs.

### Independent correlation anchors (nine-index universe)

- Highest: `[IDX_EM, IDX_WORLD]`, Pearson seconds-return correlation
  `0.973692078934`, rounded `0.974`.
- Lowest: `[IDX_CHINA, IDX_LATAM]`, Pearson correlation
  `-0.825197974433`, rounded `-0.825`.
- China versus Asia Pacific ex Japan: `0.872765241357`, rounded `0.873`; this
  exceeds the high threshold and supports a China/Asia dependence flag.
- At least one nine-index pair exceeds the `0.8` high threshold, so
  `high_threshold_breached` is true.
- China versus each permitted diversification candidate: India `0.850`,
  EM ex China `0.829`, Latin America `-0.825`. Latin America alone is below the
  `0.2` low-correlation threshold, so `diversification_candidates` should be
  exactly `["IDX_LATAM"]`.

### Unresolved semantics

- The public schema does not enumerate sleeve names or map a concentration /
  diversification finding to a unique pair of sleeve actions. Structural
  compliance and target consistency are checkable; exact action selection is
  recorded as non-unique rather than guessed.

## train_003 - Q2 2026 allocation refresh

### Contract

- Required top-level keys: `task_id`, `as_of_date`, `target_quarter`,
  `prior_quarter`, `policy_id`, `allocation_views`, `risk_overlay`.
- `task_id=train_003`, `target_quarter=Q2_2026`, `prior_quarter=Q1_2026`, and
  live as-of date `2026-05-29`.
- `allocation_views` has exactly eight rows in payload order: Europe, Japan,
  Emerging Markets, India, Latin America, U.S. Treasuries, Corporate High
  Yield, EUR. Every row has the six requested fields using their enums.
- `risk_overlay` has `overlay_code`, `primary_action`, and `rationale_codes`;
  all use permitted values and rationale ordering is highest priority first.

### Independently computed rows (Q2 signals and Q1-prior records)

| Opportunity set | Asset class | View | Change | Conviction | Rationale |
|---|---|---|---|---|---|
| Europe | Equities | OW | UP | MEDIUM | EUROPE_RECOVERY |
| Japan | Equities | UW | DOWN | MEDIUM | JAPAN_POLICY_RISK |
| Emerging Markets | Equities | UW | DOWN | MEDIUM | CHINA_DEPENDENCE |
| India | Equities | OW | UNCHANGED | HIGH | INDIA_OFFSET |
| Latin America | Equities | OW | UP | MEDIUM | LATAM_DIVERSIFIER |
| U.S. Treasuries | Duration | OW | UP | MEDIUM | DURATION_SUPPORT |
| Corporate High Yield | Credit | UW | DOWN | MEDIUM | HY_VALUATION_RISK |
| EUR | Currency | OW | UP | MEDIUM | EUROPE_RECOVERY |

- The request payload's overlay-code and primary-action lists are parallel in
  order, so a chosen overlay must use the action at the same index.
- The public contract does not state how to choose among overlays or how to
  order all possible rationale priorities. Exact overlay choice and rationale
  priority beyond source-code validity are unresolved.
- The lineage policy identifier is publicly represented both by
  `POLICY_SET_2026_05` and `POL_ALLOCATION_MAPPING`; exact choice between those
  two is unresolved unless other output context disambiguates it.

## train_004 - PF-FI-LUMEN credit rotation

### Contract

- Required top-level fields: `task_id=train_004`,
  `portfolio_id=PF-FI-LUMEN`, live `as_of_date`, `rotation.trades`,
  `risk_metrics`, `exception_flags`, `watchlist_handling`, and
  `risk_note_code`.
- Trades are sorted with all `SELL`s before all `BUY`s, then ascending
  `instrument_id` within each action. Quantities are positive numbers at one
  decimal place. Watchlist sell IDs are ascending; booleans are actual JSON
  booleans; risk metrics use the template precision.

### Independent live anchors

- Current total market value: `78.0m`.
- Current HY: Juniper `12.0m` + Lumen Auto `11.0m` + Nova `8.0m = 31.0m`;
  current HY allocation `31/78 = 39.743589...%`, rounded `39.74%`.
- Current quantity-weighted duration: `3.988461...` years, rounded `3.99`.
- Current watchlist exposure: `BND_JUNIPER_2028`, `12.0m`; the other two HY
  positions have live non-watchlist issuers.
- Current holding quantities: Juniper `12.0`, Lumen Auto `11.0`, Nova `8.0`,
  Kodiak `17.0`, Meridian `16.0`, Orbit `14.0` (USD millions).

### Hard checks and unresolved selection

- Sells must reference existing holdings and cannot exceed their live
  quantities. Buys must reference current `candidate: true` bonds and avoid
  watchlisted issuers, as required by the memo. No instrument may occur twice.
- `funding` is a sell-funded rotation, so aggregate BUY notional must equal
  aggregate SELL notional.
- Recompute every post-trade holding after applying the trades. Require
  post-trade HY `<= 20%`, post-trade duration in `[3.0, 5.0]`, watchlist
  exposure `0.0`, and HY reduction of at least `4.0` percentage points.
- All arithmetically computable metrics and exception flags must equal those
  recomputed results. `watchlist_sell_ids` must equal the sold watchlist
  instruments and `buys_avoid_watchlist` must be true.
- Multiple trade packages are feasible. Compliance and arithmetic are checked;
  a unique package will not be fabricated.
- The public contract does not define a unique mapping from the completed
  rotation to `risk_note_code`; exact choice is unresolved.
- The issuer concentration policy is not an output field in this task and the
  starting Lumen book already exceeds a 12% issuer cap. Its intended
  post-trade applicability is not uniquely specified, so it is not used to
  manufacture a unique package.

## train_005 - PF-MA-HELIO committee decision

### Contract

- Required top-level keys: `portfolio_id`, `as_of_date`, `review_quarter`,
  `correlation_summary`, `target_sleeve_actions`, `allocation_views`,
  `rebalance_trigger`, `portfolio_risk_concentration_flag`, `next_step`.
- `portfolio_id=PF-MA-HELIO`, live as-of date `2026-05-29`, and
  `review_quarter=Q2_2026`.
- `correlation_summary` has exactly two items in role order
  `highest_concentration`, then `best_diversifier`. Pairs are alphabetically
  sorted and values use three decimals.
- Sleeve actions and allocation views contain exactly four items in this order:
  Emerging Markets, India, Latin America, USD. All fields use the template's
  enums and precision.

### Independent anchors (four-index universe)

- Highest concentration: `[IDX_CHINA, IDX_EM]`, correlation
  `0.915297035099`, rounded `0.915`.
- Best diversifier: `[IDX_CHINA, IDX_LATAM]`, correlation
  `-0.825197974433`, rounded `-0.825`.
- The high-threshold correlation breach is true (`0.915 >= 0.8`), so the
  concentration flag is true and `rebalance_trigger` should identify a
  correlation-cap breach.
- Allocation rows must exactly match the Q2 mapping:
  - Emerging Markets: prior `N`, score `-0.373`, view `UW`, change `DOWN`,
    conviction `MEDIUM`, rationale `CHINA_DEPENDENCE`.
  - India: prior `OW`, score `0.732`, view `OW`, change `UNCHANGED`, conviction
    `HIGH`, rationale `INDIA_OFFSET`.
  - Latin America: prior `N`, score `0.480`, view `OW`, change `UP`, conviction
    `MEDIUM`, rationale `LATAM_DIVERSIFIER`.
  - USD: prior `OW`, score `-0.218`, view `N`, change `DOWN`, conviction `LOW`,
    rationale `NEUTRAL_BALANCE`.
- Cross-task consistency is required: the China/EM and China/LatAm values must
  match train_002, and the four allocation mappings must match train_003 where
  sets overlap.

### Unresolved semantics

- The public contract does not map active views/correlations to a unique
  `action` for each sleeve or a unique `next_step`. Structural validity and
  cross-task consistency are checked; exact governance routing is recorded as
  non-unique rather than guessed.

## Check accounting

Checks will use Python's standard library and a deterministic `unittest`
runner. Each test method is one executed check; the target is at most 60.
Results will distinguish assertion failures from execution errors and will
retain raw stdout/stderr. Unresolved requirements will be listed separately
and will not be mislabeled as assertion failures.
