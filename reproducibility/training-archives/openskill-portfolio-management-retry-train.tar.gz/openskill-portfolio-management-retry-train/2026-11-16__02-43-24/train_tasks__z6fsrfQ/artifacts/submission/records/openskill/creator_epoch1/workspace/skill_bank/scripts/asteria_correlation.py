#!/usr/bin/env python3
"""Monthly simple-return Pearson correlation workbench for Asteria snapshots.

Pearson coefficients use a 60-digit Decimal calculation. Thresholds and the
default window come from the live policy snapshot unless explicitly overridden.

Example:
  python3 asteria_correlation.py --snapshot snap.json \
    --index-ids IDX_A,IDX_B,IDX_C --out correlations.json
"""

from __future__ import annotations

import argparse
import itertools
import sys
from decimal import Decimal, localcontext
from typing import Any

try:
    from .asteria_common import (
        AsteriaError,
        as_decimal,
        load_json,
        round_half_up,
        write_json,
    )
except ImportError:  # Direct script execution puts this directory on sys.path.
    from asteria_common import (
        AsteriaError,
        as_decimal,
        load_json,
        round_half_up,
        write_json,
    )


def _correlation_policy(snapshot: dict[str, Any]) -> dict[str, Any]:
    policies = snapshot.get("policies", {})
    direct = policies.get("correlation")
    if isinstance(direct, dict):
        return direct
    for value in policies.values():
        if not isinstance(value, dict):
            continue
        if "correlation_high_threshold" in value or "correlation_low_threshold" in value:
            return value
    raise AsteriaError("Snapshot has no correlation policy")


def _series(
    levels: list[dict[str, Any]], start_date: str, end_date: str
) -> list[Decimal]:
    selected = [item for item in levels if start_date <= item["date"] <= end_date]
    selected.sort(key=lambda item: item["date"])
    if not selected:
        raise AsteriaError(f"No index levels between {start_date} and {end_date}")
    if selected[0]["date"] != start_date or selected[-1]["date"] != end_date:
        raise AsteriaError(
            f"Requested window {start_date}..{end_date} is not covered by levels "
            f"{selected[0]['date']}..{selected[-1]['date']}"
        )
    dates = [item["date"] for item in selected]
    if len(dates) != len(set(dates)):
        raise AsteriaError("Duplicate level date in requested window")
    if len(selected) < 3:
        raise AsteriaError("Pearson correlation requires at least two return observations")
    with localcontext() as context:
        context.prec = 60
        returns: list[Decimal] = []
        for previous, current in zip(selected, selected[1:]):
            previous_level = as_decimal(previous["level"])
            current_level = as_decimal(current["level"])
            if previous_level <= 0:
                raise AsteriaError(f"Non-positive index level on {previous['date']}")
            returns.append(current_level / previous_level - Decimal(1))
    return returns


def _pearson(x: list[Decimal], y: list[Decimal]) -> Decimal:
    if len(x) != len(y) or len(x) < 2:
        raise AsteriaError("Pearson inputs must be equal-length series with n >= 2")
    with localcontext() as context:
        context.prec = 60
        n = Decimal(len(x))
        mean_x = sum(x, Decimal(0)) / n
        mean_y = sum(y, Decimal(0)) / n
        covariance_numerator = sum(
            ((a - mean_x) * (b - mean_y) for a, b in zip(x, y)), Decimal(0)
        )
        sum_sq_x = sum(((a - mean_x) ** 2 for a in x), Decimal(0))
        sum_sq_y = sum(((b - mean_y) ** 2 for b in y), Decimal(0))
        denominator = (sum_sq_x * sum_sq_y).sqrt()
        if denominator == 0:
            raise AsteriaError("Pearson correlation is undefined for a constant return series")
        return covariance_numerator / denominator


def correlation_review(
    snapshot: dict[str, Any],
    index_ids: list[str],
    start_date: str | None = None,
    end_date: str | None = None,
    high_threshold: Decimal | None = None,
    low_threshold: Decimal | None = None,
) -> dict[str, Any]:
    policy = _correlation_policy(snapshot)
    start_date = start_date or policy.get("review_window_start")
    end_date = end_date or policy.get("review_window_end")
    if not start_date or not end_date:
        raise AsteriaError("Review window dates must be supplied or present in policy")
    high_threshold = (
        as_decimal(policy["correlation_high_threshold"])
        if high_threshold is None
        else as_decimal(high_threshold)
    )
    low_threshold = (
        as_decimal(policy["correlation_low_threshold"])
        if low_threshold is None
        else as_decimal(low_threshold)
    )
    index_ids = sorted(set(index_ids))
    if len(index_ids) < 2:
        raise AsteriaError("At least two unique index ids are required")
    level_store = snapshot.get("index_levels", {})
    series: dict[str, list[Decimal]] = {}
    level_count: int | None = None
    for index_id in index_ids:
        levels = level_store.get(index_id)
        if levels is None:
            raise AsteriaError(f"Snapshot has no levels for {index_id}")
        series[index_id] = _series(levels, start_date, end_date)
        observations = len(series[index_id])
        if level_count is None:
            level_count = observations
        elif observations != level_count:
            raise AsteriaError("Requested indices have different return counts")

    pairs: list[dict[str, Any]] = []
    for left, right in itertools.combinations(index_ids, 2):
        coefficient = _pearson(series[left], series[right])
        pairs.append(
            {
                "pair": [left, right],
                "correlation": round_half_up(coefficient, 3),
                "correlation_exact": coefficient,
            }
        )
    pairs.sort(key=lambda item: tuple(item["pair"]))

    highest = min(
        pairs,
        key=lambda item: (-item["correlation_exact"], tuple(item["pair"])),
    )
    lowest = min(
        pairs,
        key=lambda item: (item["correlation_exact"], tuple(item["pair"])),
    )
    high_pairs = [
        item for item in pairs if item["correlation_exact"] >= high_threshold
    ]
    low_pairs = [
        item for item in pairs if item["correlation_exact"] <= low_threshold
    ]
    pair_count = len(index_ids) - 1
    average_correlations: dict[str, Decimal] = {}
    for index_id in index_ids:
        total = sum(
            (
                item["correlation_exact"]
                for item in pairs
                if index_id in item["pair"]
            ),
            Decimal(0),
        )
        average_correlations[index_id] = total / Decimal(pair_count)
    low_candidates = sorted(
        index_id
        for index_id, average in average_correlations.items()
        if average <= low_threshold
    )
    universal_low_candidates = sorted(
        index_id
        for index_id in index_ids
        if all(
            item["correlation_exact"] <= low_threshold
            for item in pairs
            if index_id in item["pair"]
        )
    )

    return {
        "review_window": {
            "level_start_date": start_date,
            "level_end_date": end_date,
            "return_observations": int(level_count or 0),
        },
        "index_set": index_ids,
        "thresholds": {
            "high_threshold": high_threshold,
            "low_threshold": low_threshold,
            "high_test": "correlation_exact >= high_threshold",
            "low_test": "correlation_exact <= low_threshold",
        },
        "extreme_pairs": {
            "highest_positive": highest,
            "lowest": lowest,
        },
        "high_pairs": high_pairs,
        "low_pairs": low_pairs,
        "low_candidates": low_candidates,
        "universal_low_candidates": universal_low_candidates,
        "average_correlation_by_index": average_correlations,
        "pairs": pairs,
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", required=True)
    parser.add_argument(
        "--index-ids",
        required=True,
        help="Comma-separated Asteria index ids; output is sorted",
    )
    parser.add_argument("--start-date", help="First level date in YYYY-MM-DD")
    parser.add_argument("--end-date", help="Last level date in YYYY-MM-DD")
    parser.add_argument("--high-threshold", help="Override live policy threshold")
    parser.add_argument("--low-threshold", help="Override live policy threshold")
    parser.add_argument("--out", required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        snapshot = load_json(args.snapshot)
        index_ids = [part.strip() for part in args.index_ids.split(",") if part.strip()]
        result = correlation_review(
            snapshot,
            index_ids,
            start_date=args.start_date,
            end_date=args.end_date,
            high_threshold=as_decimal(args.high_threshold)
            if args.high_threshold is not None
            else None,
            low_threshold=as_decimal(args.low_threshold)
            if args.low_threshold is not None
            else None,
        )
        write_json(args.out, result)
    except (AsteriaError, KeyError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(f"wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
