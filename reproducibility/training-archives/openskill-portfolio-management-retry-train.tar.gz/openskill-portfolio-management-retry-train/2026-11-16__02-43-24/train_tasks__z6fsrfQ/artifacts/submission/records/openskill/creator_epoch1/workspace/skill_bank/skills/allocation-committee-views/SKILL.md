---
name: allocation-committee-views
description: Apply Asteria allocation policy cutoffs to live macro scores, compare target views with prior-quarter views by rank, assign conviction and rationale, select a risk overlay, and produce committee actions with correlation linkage.
---

# Allocation Committee Views

## Applicability

Use for active allocation refreshes, portfolio-level risk overlays, and multi-asset
committee decisions that combine opportunity-set views with equity correlation
findings. It covers view, change, conviction, rationale, overlay, rebalance trigger,
concentration flag, sleeve action, and next-step fields.

Read `../asteria-data-contract/SKILL.md` first. For a committee task also read
`../equity-correlation-review/SKILL.md` and use the same snapshot.

## Live Inputs

- Target and prior quarters from the request.
- Requested opportunity sets in their exact output order.
- `allocation_mapping` policy: score cutoffs, view ranks, and conviction cutoffs.
- Macro signal for each `(opportunity_set, target_quarter)`.
- Prior-view record for the same opportunity set and quarter lineage.
- Opportunity-set taxonomy for `asset_class`.
- Current portfolio holdings and correlation policy for a committee decision.

Never derive the prior view from the current score. The prior view must be read from
the prior-view record.

## Quarter and Prior-View Matching

Match a prior-view record first by:

```text
record.quarter == target_quarter
record.previous_quarter == prior_quarter
record.opportunity_set == requested opportunity_set
```

If the service labels the record by the prior quarter itself, use the unique record
with `quarter == prior_quarter` and the same opportunity set. Reject missing or
multiple matches rather than choosing by array position.

The reusable calculator is:

```bash
python3 skill_bank/scripts/asteria_allocation.py \
  --snapshot snapshot.json \
  --request allocation_request.json \
  --out views.json
```

It preserves repeated `--opportunity-set` order or, when given `--request`, the
payload's focus-order field.

## View Mapping

Read `view_score_thresholds` and `view_rank` from the live allocation policy. Let
`s` be the exact target-quarter macro score.

```text
if s >= OW_min:                  view = OW
else if s <= UW_max:             view = UW
else:                            view = N
```

The bounds are inclusive at `OW_min` and `UW_max`. Do not apply a remembered
positive/negative cutoff. Classify from the unrounded score, then round the emitted
`signal_score` to the template precision.

## View Change

Use the live rank map, normally `UW < N < OW`:

```text
target_rank > prior_rank  -> UP
target_rank < prior_rank  -> DOWN
target_rank == prior_rank -> UNCHANGED
```

Change describes the direction of the view rank, not the sign or magnitude of the
score change. `UW -> N`, `N -> OW`, and `UW -> OW` are all `UP`.

## Conviction

Use the absolute exact score and the live conviction cutoffs:

```text
abs(score) >= HIGH_abs_min   -> HIGH
else abs(score) >= MEDIUM_abs_min -> MEDIUM
else                         -> LOW
```

Cutoff values are inclusive. Conviction is independent of view direction; a large
negative score is HIGH conviction UW, not LOW.

## Rationale and Taxonomy

- Copy `rationale_code` from the matching target-quarter macro-signal record. Do not
  infer it from the view or from a driver string.
- Copy `asset_class` from the opportunity-set taxonomy, even when a local request
  omits it.
- Preserve the request's opportunity-set order. Taxonomy `display_order` is only a
  fallback when the template explicitly requests taxonomy order.
- Preserve allowed enum spelling and case exactly.

A typical template-ready row has:

```json
{
  "opportunity_set": "...",
  "asset_class": "Equities|Duration|Credit|Currency",
  "prior_view": "UW|N|OW",
  "signal_score": 0.000,
  "view": "UW|N|OW",
  "change": "UP|DOWN|UNCHANGED",
  "conviction": "LOW|MEDIUM|HIGH",
  "rationale_code": "..."
}
```

Do not include the exact unrounded score or source metadata in a strict answer
unless the template allows extra keys.

## Risk Overlay Decision Rule

Select the overlay from the focused allocation evidence using this priority order:

1. **Duration quality tilt** when at least one `Duration` row is `OW` and at least
   one `Credit` row is `UW`. Emit `DURATION_QUALITY_TILT` and
   `tilt_to_duration_quality`, using the contributing duration/credit rationale
   codes in template business-priority order.
2. **Credit risk reduction** when there is a credit `UW` but no duration `OW` with
   which to pair it. Emit `CREDIT_RISK_REDUCTION` and `trim_credit_beta`, using the
   credit-risk rationale codes.
3. **Equity beta extension** when equity `OW` evidence dominates equity `UW` and no
   stronger duration/credit defensive rule applies. Emit `EQUITY_BETA_EXTENSION`
   and `add_cyclical_equity_beta` with the contributing equity upside codes.
4. **Currency defensive hedge** when currency `UW` or a `DOLLAR_DEFENSIVE` rationale
   is the material defensive signal and no stronger rule applies. Emit
   `CURRENCY_DEFENSIVE_HEDGE` and `add_currency_hedge`.
5. **No overlay** when no material tilt is supported. Emit `NO_OVERLAY` and
   `hold_policy_weights`; use the allowed neutral rationale or an empty list only if
   the template permits it.

For `rationale_codes`, include unique codes from the actual contributing rows, do
not copy every focused row's code, and order them by the answer template's enum
ordering when that ordering communicates business priority. A duration/credit
quality tilt normally cites the positive duration reason and the negative credit
reason, not unrelated country views.

## Committee Linkage

When a committee template ties correlation to allocation:

1. Compute correlations first with the shared index window and policy thresholds.
2. Put the maximum exact pair first as `highest_concentration`; put the minimum exact
   pair second as `best_diversifier`. Sort IDs within each pair.
3. Read target-quarter views and prior views using the rules above.
4. Set `portfolio_risk_concentration_flag` to true when any pair meets the live high
   threshold. This is a risk flag, not a claim that the market value is illegal.
5. Set the trigger by evidence priority: correlation cap breach, then HY cap
   pressure, then duration drift, then watchlist concentration, otherwise committee
   review.
6. Map target sleeve actions primarily from active views: `OW -> add`, `N -> hold`,
   `UW -> trim`. A currency row may use `hedge` when an explicit hedging mandate or
   defensive currency rationale applies; otherwise `hold` for neutral. Use
   `monitor` for a neutral risk watch and `rotate` only when the task explicitly
   frames a source-to-destination rotation.
7. When a high-correlation concentration flag is true and the proposed actions trim
   the offending sleeve and add a low-correlation diversifier, the next step is
   normally `approve_rotation`. If the breach has no actionable remedy, use
   `defer_pending_risk_review`; if a hard constraint is irreconcilable, use
   `reject_constraint_breach`. If no material breach exists, prefer
   `approve_with_monitoring`.

Keep the correlation summary and allocation rows in the template's exact item order.

## Output Checks

- Target and prior quarter strings match the request and live record lineage.
- `policy_id` is the allocation mapping policy actually used.
- `allocation_views` length equals the focused-set request length and preserves its
  order.
- Every `prior_view`, `view`, `change`, `conviction`, and `rationale_code` is allowed.
- Scores use the requested precision and were classified before rounding.
- A duration/credit overlay has matching code/action and only contributing rationale
  codes.
- Committee correlation pairs use alphabetical IDs and three-decimal exact-derived
  correlations.
- Trigger, concentration flag, and next step agree with the live thresholds and
  proposed actions.

## Pitfalls

- Deriving prior views by applying today's cutoffs to an old macro score.
- Selecting the next quarter's prior-view records because the opportunity-set name
  matches.
- Sorting by taxonomy order when the request explicitly lists focus order.
- Using `>` instead of the live inclusive cutoff at a boundary.
- Assigning conviction from the view label rather than absolute score.
- Treating `UNCHANGED` as “score unchanged”; only view rank matters.
- Adding every rationale code in the universe to an overlay.
- Linking a correlation finding to an unrelated sleeve instead of reading current
  holdings and index membership.
- Claiming a committee rotation is approved when a material unresolved breach lacks
  remedial action.

