#!/usr/bin/env python3
"""Fetch one coherent Asteria public-data snapshot over HTTP.

Example:
  python3 asteria_snapshot.py \
    --base-url "$ASTERIA_BASE_URL" \
    --portfolio "$PORTFOLIO_ID" \
    --out snapshot.json
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from typing import Any

try:
    from .asteria_common import AsteriaError, http_get_json, write_json
except ImportError:  # Direct script execution puts this directory on sys.path.
    from asteria_common import AsteriaError, http_get_json, write_json


ENDPOINTS = {
    "policies": "/api/policies",
    "portfolios": "/api/portfolios",
    "bonds": "/api/instruments/bonds",
    "issuers": "/api/issuers",
    "energy": "/api/market/energy",
    "indices": "/api/indices",
    "index_levels": "/api/index-levels",
    "opportunity_sets": "/api/allocation/opportunity-sets",
    "prior_views": "/api/allocation/prior-views",
    "macro_signals": "/api/macro-signals",
}


def _portfolio_index(records: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {record["portfolio_id"]: record for record in records}


def _assert_coherent(
    service_as_of: str,
    selected_portfolios: list[str],
    portfolio_map: dict[str, dict[str, Any]],
    holdings: dict[str, dict[str, Any]],
) -> dict[str, str]:
    dates: dict[str, str] = {"policies": service_as_of}
    for portfolio_id in selected_portfolios:
        dates[f"portfolio:{portfolio_id}"] = portfolio_map[portfolio_id]["as_of_date"]
        dates[f"holdings:{portfolio_id}"] = holdings[portfolio_id]["as_of_date"]
    distinct = set(dates.values())
    if len(distinct) != 1:
        details = ", ".join(f"{key}={value}" for key, value in sorted(dates.items()))
        raise AsteriaError(f"Selected records are not one coherent as-of snapshot: {details}")
    return dates


def build_snapshot(base_url: str, requested_portfolios: list[str]) -> dict[str, Any]:
    records: dict[str, Any] = {}
    for name, path in ENDPOINTS.items():
        records[name] = http_get_json(base_url, path)

    if not isinstance(records["policies"], dict):
        raise AsteriaError("/api/policies did not return an object")
    if not isinstance(records["portfolios"], list):
        raise AsteriaError("/api/portfolios did not return a list")
    if not isinstance(records["index_levels"], dict):
        raise AsteriaError("/api/index-levels did not return an object keyed by index id")

    portfolio_map = _portfolio_index(records["portfolios"])
    selected = requested_portfolios or sorted(portfolio_map)
    missing = [portfolio_id for portfolio_id in selected if portfolio_id not in portfolio_map]
    if missing:
        raise AsteriaError(f"Unknown portfolio id(s): {', '.join(missing)}")

    holdings: dict[str, dict[str, Any]] = {}
    for portfolio_id in selected:
        response = http_get_json(
            base_url, f"/api/portfolios/{portfolio_id}/holdings"
        )
        if response.get("portfolio_id") != portfolio_id:
            raise AsteriaError(
                f"Holdings response portfolio_id {response.get('portfolio_id')!r} "
                f"does not match requested {portfolio_id!r}"
            )
        if not isinstance(response.get("holdings"), list):
            raise AsteriaError(f"Holdings for {portfolio_id} are not a list")
        holdings[portfolio_id] = response

    service_as_of = records["policies"].get("as_of_date")
    if not service_as_of:
        raise AsteriaError("Policy set has no as_of_date")
    if records["energy"].get("as_of_date") != service_as_of:
        raise AsteriaError(
            "Energy market as_of_date does not match policy set: "
            f"{records['energy'].get('as_of_date')!r} != {service_as_of!r}"
        )
    date_map = _assert_coherent(service_as_of, selected, portfolio_map, holdings)

    index_level_dates: dict[str, dict[str, str]] = {}
    for index_id, levels in records["index_levels"].items():
        if not isinstance(levels, list) or not levels:
            raise AsteriaError(f"Index {index_id} has no level records")
        dates = [item.get("date") for item in levels]
        if len(dates) != len(set(dates)):
            raise AsteriaError(f"Index {index_id} has duplicate level dates")
        ascending = sorted(levels, key=lambda item: item["date"])
        index_level_dates[index_id] = {
            "level_start_date": ascending[0]["date"],
            "level_end_date": ascending[-1]["date"],
            "level_count": len(ascending),
        }

    return {
        "metadata": {
            "base_url": base_url.rstrip("/"),
            "fetched_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "as_of_date": service_as_of,
            "selected_portfolios": selected,
            "coherent_portfolio_dates": date_map,
            "endpoint_paths": ENDPOINTS,
            "index_level_ranges": index_level_dates,
        },
        "policies": records["policies"],
        "portfolios": records["portfolios"],
        "holdings_by_portfolio": holdings,
        "bonds": records["bonds"],
        "issuers": records["issuers"],
        "energy": records["energy"],
        "indices": records["indices"],
        "index_levels": records["index_levels"],
        "opportunity_sets": records["opportunity_sets"],
        "prior_views": records["prior_views"],
        "macro_signals": records["macro_signals"],
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-url",
        required=True,
        help="Asteria service base URL read from the current environment instructions",
    )
    parser.add_argument(
        "--portfolio",
        action="append",
        default=[],
        help="Portfolio id whose holdings should be included; repeat as needed",
    )
    parser.add_argument("--out", required=True, help="Output snapshot JSON path")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        snapshot = build_snapshot(args.base_url, args.portfolio)
        write_json(args.out, snapshot)
    except AsteriaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(
        f"wrote {args.out}: as_of={snapshot['metadata']['as_of_date']} "
        f"portfolios={','.join(snapshot['metadata']['selected_portfolios'])}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
