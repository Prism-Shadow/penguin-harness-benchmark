# Optimizer Meta Guidance

Persistent optimizer-only memory. Never install this file in a solving Skill.

## Epoch 1 observations

- The initial Skill produced four partial failures and one complete success (`train_005`). All actors respected the frozen-Skill and no-judge boundary.
- The strongest concrete diagnosis is the P2P appeal deadline in `train_004`: the actor used the P2P discussion timestamp as the final adverse determination date. The task's reporting/closure date is the relevant final determination date when no explicit adverse-determination date exists.
- Audit fields are a likely secondary failure source. Prefer real environment record IDs over criterion IDs, enum tokens, or field names in `controlling_record_ids` and `exception_record_ids`.
- Do not overfit by rewriting correct arithmetic, approval, appeal-path, or claim-repricing decisions. Preserve them with localized edits.

## Productive edit strategy

- Make the smallest change that resolves one observed decision error.
- Generalize from the missing operational rule, not from the instance ID or value.
- Re-evaluate every selection task after any edit; never reuse an earlier answer as a candidate measurement.

## Epoch 1 rejection lessons

- The candidate's broad packet and record-ID rewrites reduced the mean by 0.0825. Broad audit rewrites are low-confidence; prefer one isolated semantic fix.
- `required_packet_items` should follow the packet's stated base requirements. A missing substantiation record belongs in `missing_packet_items`, not necessarily in the required list.
- Do not replace the recorded P2P deadline derivation until isolated. The original discussion-timestamp-derived deadline may be intended; diagnose audit separately.
- Margin exception IDs are narrower than controlling IDs: include the below-threshold contract-gap row, not every charge-sensitive row.

## Epoch 2 observations

- Explicit audit-ordering instructions and preserved base packet requirements tied the incumbent, not improved it. Stop investing edit budget in wholesale audit-list rewrites.
- Identical epoch-1 and epoch-2 snapshots scored differently only on tasks 2 and 5 in paired runs. Treat those as stochastic stability risks, not evidence of a Skill improvement.
- Tasks 1, 3, and 4 have persistent one-group misses. Future proposals should isolate a single semantic field at a time so the gate can identify whether that field is responsible.
- A slow-update tie is a rejection; do not keep additional prose merely because it sounds prudent.

## Epoch 3 observations

- The P2P date hypothesis is now settled causally: switching from the recorded discussion timestamp to the reporting/closure date reduced `train_004` from 0.909091 to 0.818182. Retain `scheduled_at` + stated calendar window when no separate determination-date record exists.
- Tasks 1 and 3 remain persistent one-group partials, and task 4's partial is not caused by the deadline.
- With only one fast step remaining, test a narrow audit set/order hypothesis rather than broad semantic changes.

## Epoch 4 and final observations

- Restricting controlling IDs to operational source records reduced task 2 from 0.916667 to 0.833333 and did not improve tasks 1, 3, or 4. Do not repeat this direction.
- Across four epochs, every accepted gate remained at the initial checkpoint. The baseline Skill's decision procedures are strong and stable; most residual misses are isolated rubric details that could not be improved by broad prose.
- Repeated identical-skill executions showed variance mainly in task 2 audit/package details and task 5 exception-list composition, not in the decisive business outcomes.
- Preserve the established Skill exactly for deployment: its selection mean is 0.9318184 and its digest is 81548f75f06d1651a0c67377dae2cee4e418e92b094c7d36e932569d68e4bed9.
