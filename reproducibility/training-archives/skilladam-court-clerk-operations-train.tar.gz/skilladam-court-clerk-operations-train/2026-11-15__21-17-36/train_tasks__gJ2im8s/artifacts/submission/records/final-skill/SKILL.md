---
name: court-operations-closeout
description: "Reconcile court hearing records, CMS/charge data, fee schedules, payment policies, and local forms into clerk-ready disposition, financial, docket, and supervision JSON."
version: 0.1.0
---

# Court operations closeout

Use this Skill for court-clerk tasks covering criminal dispositions, traffic citations, sentencing orders, fee posting, payment plans, probation/license forms, docket entries, and register totals. The goal is a defensible closeout based only on authoritative records. Do not invent facts, amounts, identifiers, contact details, or dates.

## 1. Start from the contract

1. Read every local payload, including the answer template, before querying. The template is the output contract: preserve required keys, exact enum spelling, ordering, date format, and currency precision.
2. List the target case, citation, or petition identifiers. Treat every target as separate; do not borrow data from a similarly named person or another case.
3. Keep all filesystem reads inside the assigned task directory and your workspace. Read only the public business API. Do not use a training judge or any prior answers/feedback.
4. Work from a short evidence table: target ID, role, identity, counsel, charges, disposition, sentence, balances, fees, policy, forms, missing data, and unresolved conflicts.

## 2. Query the portal efficiently and completely

The API result lists may be paginated or capped, so never conclude that a record is absent from the first page alone.

- Cross-record lookup: `GET /api/search?q=<case-or-citation-id>` and inspect `result_type`. Use it to find case, docket, and petition records, but not as the only source for charges.
- Direct filtered lookup: `GET /api/charges?case_number=<id>`, `GET /api/cases?case_number=<id>`, and `GET /api/docket-entries?case_number=<id>`.
- Reference data: retrieve `GET /api/jurisdictions`, `GET /api/fee-schedules`, `GET /api/payment-policies`, and `GET /api/forms`, then filter locally by jurisdiction and identifiers. Relevant filters such as `form_id` or `q` are useful when exposed.
- Citation records: retrieve `GET /api/citations` and select the exact citation number.
- Financial petitions: use `GET /api/financial-petitions?case_number=<id>` or retrieve all and filter by exact petition ID.
- Prefer compact parsing (for example, Python that prints only matching records) over dumping whole tables.

Record both the source value and the corrected value for every conflict.

## 3. Apply the source hierarchy

Use the most specific authoritative source for each field:

1. A signed final order, final hearing minute, or explicit on-record judge statement controls disposition, plea, sentence, departure, and conditions.
2. CMS/case and docket records control stable case metadata when not contradicted: case number, disposition date, defendant identity/DOB, counsel classification, and status.
3. A corroborating memo, supervisor note, or local form excerpt resolves a shorthand label only when it expressly does so.
4. Draft finance queues, worksheets, scratchpads, intake cover sheets, and legacy charge screens are provisional. They may supply candidate amounts but never override a final order or current schedule.

Special precedence rules:

- Hearing notes that replace a count, adjudicate guilt, waive a fee, or describe a signed order override the stale charge screen and draft worksheet.
- If identity or counsel in a finance queue conflicts with CMS and the hearing packet confirms CMS, use CMS and record an audit finding.
- `APD` or another ambiguous calendar label is not automatically public defender. If the record says appointed private/county-paid, classify `appointed_private`.
- A blank DOB stays unresolved even if a search finds a similarly named person. Use the required placeholder and a verify action.
- A matter is not disposed merely because a queue or draft worksheet says so. No signed final order means hold or exclude financial posting.

## 4. Resolve dispositions and departures

- Determine plea, finding, and charge disposition separately; `not guilty` plea plus a later guilty verdict is a valid combination.
- Use the charge's actual convicted count after amendment, not the superseded original count.
- Count amended-away or dismissed counts separately from convicted counts.
- Enter a departure only when the controlling final order/minute expressly states a durational or dispositional departure. A stale CMS `departure_type`/reason, a plea-agreement cap, or “top of range” language is not by itself a departure.
- Use `no_departure` for a disposed felony/serious count with no explicit departure. Use the template's misdemeanor/not-evaluated value where provided for a minor count not analyzed for departure. Use the pending/not-entered value where no disposition occurred.
- When an unsigned or continued matter is before the court, do not enter a disposition date, plea, conviction count, or financial posting unless the template expressly asks for the draft status.

## 5. Apply fees only when supported

For each case, determine the disposition date first, then select only current fee rows effective on that date.

Circuit-criminal (Arkansas) patterns:

- Apply the current circuit criminal court cost once per disposed case.
- Apply a public-defender user fee only when counsel is a public defender. Do not apply it to retained or appointed-private counsel.
- Apply a drug assessment only to a qualifying controlled-substance conviction, using the schedule effective on disposition. Ignore archived amounts.
- Apply a crime-laboratory fee only to a qualifying controlled-substance conviction and only in the jurisdiction whose current schedule provides it.
- A non-drug amended conviction does not inherit the original drug assessment/lab fee.
- Do not add account-management, collection, late, DMV, restitution, copy, certification, or other fees unless the final order or current policy supports them.

Traffic (Oregon) patterns:

- Match the violation code and speed tier to the current standard-fine row effective for the event/hearing; do not substitute an older year or the statutory maximum.
- Add the county surcharge once per citation when the current schedule requires it.
- Calculate amount due as current standard fine plus mandatory surcharge.
- Exclude event-triggered fees (late, collection, DMV, returned check, traffic school, account management) unless the minute/policy records the triggering event.
- Exclude stale schedules and expired rows.
- Use the local payment-plan form for the citation's jurisdiction; when no separate account exists, the citation number is the account reference.

Virginia Gloucester financial patterns:

- Use the current Gloucester first-petition policy band and its current account-fee amount (often zero). Do not carry an old counter worksheet fee.
- Determine disposable income as verified monthly income minus listed monthly obligations.
- Select the petitioner's requested monthly amount when it is within policy and affordable; otherwise classify it against the policy band/affordability rules in the template.
- Restitution comes before fines and costs when a restitution balance exists; otherwise the application order is fines/costs only.
- A payment plan entered at the first post-disposition petition is an initial installment. A later/default review is a subsequent review.

## 6. Calculate payment schedules exactly

Use monthly arithmetic unless the task specifies another interval.

Given total due `T`, down payment `D`, monthly amount `M`, and first due date `F`:

- Remaining balance = `T - D`.
- `total_installments = ceil((T - D) / M)`.
- `full_installment_count = floor((T - D) / M)`.
- Final payment = `(T - D) - full_installment_count * M`; if the division is exact, the final payment equals a regular installment and no extra remainder installment is added.
- If a remainder exists, final due date = `F` plus `full_installment_count` calendar months; the final installment is the remainder.
- If the division is exact, final due date = `F` plus `total_installments - 1` calendar months.
- Return-to-court date = `final_due_date + policy.return_to_court_offset_days`. Do not offset from the first due date.
- Round money to cents only at output. Keep date math in calendar months, not 30-day approximations.
- Payment `first_due_date` may come from an approved minute, a petition candidate date, or policy day count; prefer the most specific source.

## 7. Handle register, docket, and batch exclusion correctly

- A disposed case with a signed order receives a disposition/register entry and its supported financial total.
- An unsigned, continued, deferred-without-final-order, or otherwise pending matter receives a hold/exclusion entry as the template requires. Its financial posting is zero and it is excluded from assessed-case totals.
- Docket summary codes, entry types, and register actions must come from the supplied enum. Do not substitute prose.
- Batch totals include only posted/assessed matters. Keep counts and category totals internally consistent with the case-level entries.
- Sort every array exactly as the template requires.

## 8. Complete forms and placeholders

- Look up the exact current form by jurisdiction and form family/ID. Copy the portal's form ID and label.
- Use the exact placeholder required by the materials, commonly `TBD from case file`, for missing identifiers, addresses, phone numbers, license numbers, and unavailable officer/office details.
- Do not invent a SSN, driver-license number, address, phone, probation officer, office, report time, or account number.
- License consequences ordinarily run from the conviction date. Use a release date only when the controlling note expressly says the license period starts on release; do not infer release from jail credit.
- Include every required placeholder field in the designated placeholder collection, ordered as the template specifies.
- Excluded financial items should list only enumerated, unsupported items that the intake/order/policy actually presents or warns against. Give the correct reason and do not silently fold them into a balance.

## 9. Reconcile before writing

Build a per-target arithmetic table and cross-check it against the local evidence and portal:

- Identity/counsel/status matches the selected authority.
- Every charge has the correct count, offense code, plea, disposition, sentence, probation, and departure.
- Fee lines use current, jurisdiction-specific schedules and correct counsel/conviction triggers.
- Case total equals its fee lines; batch totals equal the included case entries.
- Held/excluded matters never contribute to posted totals.
- Payment math: `down + full_count*M + final = total`; total installments equals full count plus remainder installment when needed.
- Dates are ISO, month arithmetic is correct, and return dates follow the policy offset from final due.
- Form metadata, enums, ordering, and placeholders exactly match the template.
- Output only the JSON object requested. Do not include explanatory prose, markdown, comments, or unsupported extra fields.

## 10. Frequent failure modes to recheck

- Reusing a stale fee schedule or archived assessment.
- Treating appointed-private counsel as a public defender.
- Carrying a draft conviction or deposit for a continued/unsigned matter.
- Reporting a departure merely because the CMS charge row contains a departure label.
- Misreading a guilty verdict as a not-guilty plea, or vice versa.
- Borrowing a DOB for a similarly named person.
- Charging event-triggered fees without a trigger.
- Computing a return date from the first installment rather than the final installment.
- Starting a license suspension from release when the controlling rule is conviction.
- Leaving out a mandatory surcharge or applying it more than once.
- Posting a counter-note account fee that the current policy sets to zero.
