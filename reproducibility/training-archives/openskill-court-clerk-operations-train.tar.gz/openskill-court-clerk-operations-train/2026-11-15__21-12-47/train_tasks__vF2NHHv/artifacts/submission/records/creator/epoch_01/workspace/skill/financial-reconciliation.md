---
name: financial-reconciliation
description: Deterministically select effective and supported court fees, classify posts/exclusions/holds, compute balances and payment schedules with exact date arithmetic, and reconcile batch totals.
---

# Financial Reconciliation

## Applicability

Use this Skill after matter facts have been resolved whenever a task requires
fee selection, a financial register, fines/costs/assessments, restitution,
account-fee treatment, installment schedules, return dates, license periods, or
batch totals. It also governs the numeric validation of any financial answer.

## Procedure

1. **Establish the controlling event date and status.** Use the final disposition
   or order date for fee effectiveness. A held, deferred, continued, or unsigned
   matter does not receive completed sentencing financials.
2. **Build an eligibility matrix.** For each possible fee, record its code/type,
   jurisdiction, mandatory flag, triggering event, effective interval, counsel
   or charge condition, and source. A fee is includable only when all applicable
   conditions are true.
3. **Select the temporally effective row.** Match jurisdiction and fee type or
   code, then require `effective_date <= controlling_date` and either no end date
   or `controlling_date <= end_date`. If multiple rows qualify, choose the row
   with the latest effective date and consistent label/trigger; never use an
   expired, archived, or superseded amount.
4. **Classify each component.** Mark a component `post` when supported now;
   `exclude` when no order, trigger, eligibility, or effective schedule supports
   it; and `hold` when finality itself is missing. Do not add late, collection,
   DMV, returned-payment, account-management, copy, certification, or program
   fees without an explicit current policy, order, and triggering event.
5. **Apply special conditions literally.** Post a public-defender user fee only
   when the counsel role qualifies and the effective schedule requires/allows
   it. Post an assessment only for the qualifying adjudicated charge or stated
   assessment trigger. Do not carry a fee attached only to an amended-away or
   dismissed count.
6. **Reconcile a payment order.** Assemble total due only from supported
   components. Subtract any authorized down payment. Apply the payment-
   application order from the order/policy. Treat an account fee as included
   only when current policy/order makes it payable; otherwise exclude it.
7. **Select the installment.** Honor an approved amount when present. Otherwise
   use the requested amount when it fits both policy band and disposable income;
   if the request is outside the band, choose a policy-compliant amount and
   explain the classification. A request below policy minimum is not silently
   raised without authority unless the contract's policy rule requires it.
8. **Compute the plan deterministically.** With `A` as payable balance after
   down payment and `P` as monthly amount:
   `full_count = floor(A / P)` and `remainder = A - full_count * P`.
   If `remainder > 0`, add one final installment; otherwise the final payment is
   a full payment. Total count equals the number of regular full payments plus
   any remainder installment. Use decimal arithmetic and round only at the
   cent boundary, half up.
9. **Do calendar arithmetic.** Add the policy/order day offset to establish the
   first due date. Advance by whole calendar months for later installments,
   clamping the day to the month's last valid day when needed. The final due date
   is the first due date advanced by the number of intervals up to the final
   installment. If a return-to-court offset is supplied, add it after the final
   due date. Do not invent a time; use only an authoritative time or the exact
   contract placeholder.
10. **Compute supervision/license terms separately.** Start a license period
   from the basis expressly required by the order/policy, then add the specified
   whole months. Do not substitute release, filing, or petition date when the
   governing materials specify conviction date.
11. **Aggregate only posted records.** Recalculate component totals, held/
    excluded counts, and the grand total from the final included ledger. A held
    matter contributes zero to posted totals.
12. **Run independent checks.** Re-add every fee set, every schedule, and every
    batch total. Verify dates are ordered, the classification matches the
    arithmetic, and no excluded amount leaked into a balance.

## Evidence priority rules

- Current effective fee schedule for amount, fee type, mandatory status, and
  date interval.
- Current payment policy for band, down payment, account fee, application order,
  and return offset.
- Signed order or approved petition for the selected amount and any departure
  from policy defaults.
- Current case/petition ledger for balances.
- Counter notes, old forms, draft worksheets, and queues only for identifying a
  possible issue; never for the final amount or trigger.

When sources conflict, use the source that governs the field: schedule for the
fee amount, policy for the program rule, and signed/current matter record for
what was actually ordered.

## Validation checklist

- Every included fee has jurisdiction, trigger, and effective-date support.
- Expired and excluded amounts contribute zero.
- Counsel/assessment conditions match the resolved conviction facts.
- Total due equals the sum of included components, less only an authorized
  adjustment stated by the task.
- Full-payment count, remainder count, final amount, and total count satisfy the
  quotient/remainder equation.
- First, final, and return dates follow the specified day/month offsets.
- Payment application order and account-fee treatment match current policy.
- Held/excluded matters remain out of the posted register.
- Batch totals equal the exact sum of final included entries.

## Common failure modes

- Selecting an old schedule row that was effective only in a prior period.
- Using a queue total instead of rebuilding it from effective components.
- Charging a public-defender fee for appointed private or retained counsel.
- Posting an assessment after the underlying count was amended away.
- Treating `X.00` in JSON as evidence of a fee when eligibility is absent.
- Off-by-one installment counts or forgetting the final remainder.
- Adding months by 30-day blocks instead of calendar months.
- Counting held or excluded money in a posted register total.
