---
name: answer-contract-mapping
description: Inspect the supplied answer template and serialize verified facts into exactly its required structure, enum vocabulary, ordering, identifier conventions, date formats, numeric precision, null/boolean treatment, and allowed fields.
---

# Answer Contract Mapping

## Applicability

Use this Skill before evidence collection to inventory the requested shape and
again after reconciliation to produce the final JSON. It applies to every task,
including templates that are descriptive rather than a formal JSON Schema.

## Procedure

1. **Read the concrete template.** Identify required top-level keys, every
   nested object and array item, required versus allowed fields, fixed values,
   enum domains, type rules, ordering rules, identifier rules, placeholder text,
   and stated null/boolean conventions. Do not infer fields from similar tasks.
2. **Create a contract checklist.** For each output leaf record its path,
   required/allowed status, type, enum domain, source fact, formatting rule, and
   validation expression. Mark fixed strings and exact placeholder values.
3. **Check for schema variants.** Some templates supply `required_top_level_keys`;
   others define sections by example. In either case, include all sections the
   task requires and no speculative extras. A fixed top-level task identifier is
   included only when the template explicitly contains it.
4. **Map resolved facts by meaning, not label similarity.** Connect the evidence
   table to each target path. If a required fact is absent, use only the exact
   allowed placeholder; if the contract has no placeholder and the true value is
   unknown, leave the task unresolved rather than inventing one.
5. **Apply enum vocabulary exactly.** Use the spelling, case, underscores, and
   spacing from the template. Never replace an enum with prose, synonyms, or a
   number. Choose `null` only where the contract says or clearly types the leaf
   as nullable; do not use the string `"null"`.
6. **Apply ordering after completion.** Sort arrays by the named key(s), using
   deterministic lexical/numeric ordering. Apply secondary or documented
   tie-breakers; if the task supplies multiple ordering rules, honor each array
   independently. Preserve an explicitly required label/list order rather than
   alphabetizing it.
7. **Apply temporal and numeric formats.** Emit ISO calendar dates and local
   datetimes in the exact required forms. Quantize money to cents with decimal
   arithmetic. JSON numbers must remain numbers; do not add currency symbols,
   commas, or units.
8. **Enforce identifier rules.** Use the contract's account-reference rule,
   fixed-party convention, and placeholder exactly. Do not substitute a related
   case number, petition number, citation number, or external ID unless the
   template expressly requires that substitution.
9. **Strip non-contract content.** Output one JSON object, no markdown fences,
   commentary, audit narration, or fields not present in the template. Keep
   evidence notes in the separate evidence artifact.
10. **Validate locally.** Parse the final file with a JSON parser. Walk the
    template and check required keys, unknown keys, types, enum membership,
    fixed constants, list ordering, date/datetime syntax, numeric precision, and
    null/boolean representation. Then re-run the financial and total arithmetic
    on the serialized values. Repeat until both structure and arithmetic pass.

## Evidence priority rules

The answer template controls presentation and allowed vocabulary; resolved
matter evidence controls factual values. A source fact that cannot be represented
without violating the template is a known limit to report, not a reason to add a
new field. If a task-specific instruction and a generic convention conflict, the
task-specific instruction wins. If a template is ambiguous, choose the smallest
structure that includes all expressly required fields and remain consistent
within the answer.

## Validation checklist

- Valid JSON; one object; no markdown or prose.
- Every required top-level and nested key is present.
- No unpermitted fields were added.
- Enum values are exact and complete.
- Fixed IDs, labels, placeholders, and account-reference rules are exact.
- Arrays obey all documented sorts and explicit list orders.
- Dates/datetimes match their required forms.
- Numeric fields are numbers quantized to cents where required.
- Booleans are booleans and permitted nulls are JSON null.
- Serialized entry counts and totals equal the independently recomputed values.

## Common failure modes

- Copying a schema convention from another task instead of this template.
- Adding a helpful field that is not allowed.
- Using prose where an enum is required, or a similarly spelled enum.
- Sorting by a display name instead of the required identifier/key.
- Emitting a date without zero-padded month/day or a time with extra precision.
- Writing money as a quoted string or including a currency symbol.
- Using a placeholder in an unapproved field or inventing a value.
- Passing JSON syntax while failing enum, ordering, or arithmetic checks.
