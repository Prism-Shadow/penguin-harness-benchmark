---
name: trace-skill-bank
description: Route payer-operations work to focused, evidence-backed operating procedures.
version: 2026.11.15
---

# TRACE skill bank

Read `catalog.json`. For each entry whose routing description plausibly applies to the current task, read its relative `entries/<id>/SKILL.md` before taking business actions. Select only entries needed for the work, follow their observable checks, and verify the final result against the task's answer template. If no entry applies, proceed without bank guidance.
