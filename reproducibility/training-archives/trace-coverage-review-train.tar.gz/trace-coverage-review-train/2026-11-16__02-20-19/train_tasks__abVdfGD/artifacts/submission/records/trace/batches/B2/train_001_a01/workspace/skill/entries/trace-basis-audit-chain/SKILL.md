---
name: trace-basis-audit-chain
description: Use whenever the answer template requires a basis_audit with source precedence, controlling records, exception records, and an ordered precedence trail.
version: 2026-11-15.3
---

# Construct the basis audit chain

## Core rule

Every ID must resolve to an actual source row. Target cases, governing policies, request/case header rows, derived authorization/status rows, and labels for missing fields are decision context or outputs, not audit evidence. Criterion keys may appear only as gap/exception identifiers when the database records an unresolved or stale-schedule criterion; they never replace the underlying evidence.

Use the template's source-precedence enum that matches the controlling business question.

## Prior authorization

- Controlling: current clinical-evaluation and plan-of-care document IDs whose facts establish the criteria, in document order.
- Exceptions: stale, excluded, or contradictory document IDs.
- Never add the policy, case, request, authorization, or criterion keys.

## Pharmacy appeal and assistance

- Controlling: the appeal event ID, then the current packet-document IDs needed for authorization, denial, and prescriber rationale, then the documented medication-trial ID.
- Exceptions: the unmet/partial criterion key first, then the undocumented or insufficient medication-trial ID. Order gap identifiers before insufficient source records.
- Never add the policy, case row, derived assistance label, or a field name such as income proof as an ID.

## Claim benchmark correction

- Controlling: the current remittance/EOB document ID, then the selected effective benchmark IDs for the claim lines in line order.
- Exceptions: the stale-schedule criterion key first, then the rejected stale benchmark ID.
- Never add the governing policy, claim header, or claim-line rows.

## Peer-to-peer final review

- Controlling: the completed P2P event ID, then the current clinical document ID carrying the patient-specific facts.
- Exceptions: the unresolved criterion key first, then the document-fact ID for its unsupported factor.
- Never add the governing policy, case row, authorization/status row, or covered-indication fact to exceptions.

## Therapy margin queue

- Controlling: the below-threshold row ID or row IDs that directly establish the top issue. If no row is below threshold, use the row or rows that establish the requested threshold conclusion.
- Exceptions: every below-threshold issue row first, then every charge-sensitive routing row, in requested-row order. A threshold row can therefore belong to both controlling and exception lists; list it only once in the combined trail.
- Never add the case or policy.

## Ordering

- `controlling_record_ids`: controlling records in operational decision order.
- `exception_record_ids`: business gaps, denials, or threshold issues before stale sources or routing exceptions.
- `precedence_record_order`: controlling records first, then exceptions; preserve each list's order and remove duplicates only from the combined trail.

## Verification

Confirm each ID exists as the stated entity type, no context row leaked into evidence, all gaps precede stale sources in exceptions, and threshold-before-charge-sensitivity ordering is preserved.
