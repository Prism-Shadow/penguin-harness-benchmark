---
name: margin-queue-analysis
description: Analyze exactly the requested Northstar service-margin queue rows for a reporting period, applying the 120-percent revenue-to-cost threshold before charge-sensitivity routing.
---

# Margin Queue Analysis

## Applicability

Use for a monthly UM-finance service-margin queue where the task supplies exact row IDs and finance definitions. Do not add rows from the period, reorder rows by severity, or substitute payer totals for the listed service/CPT rows.

Required source precedence: `margin_threshold_then_charge_sensitivity`.

## Evidence acquisition

Read `../references/data-map.md`. Bind the task's reporting period and exactly the IDs in `finance_memo.queue_row_ids`; no broad period scan is permitted.

For each returned row capture:

- `month_id`, `period`, `payer`, `payer_segment`, `service_domain`, `cpt_code`, `visits`;
- `net_revenue`, `variable_cost`, `fixed_cost_allocated`, `charge_sensitive`.

Before calculating, verify:

- returned row count equals the memo ID count and the sets are identical;
- no returned ID includes a prohibited suffix or belongs to another period;
- all three dollar inputs are present and at no finer than cents;
- `payer_segment` and `service_domain` are exact template enums.

Reorder returned rows into the exact `finance_memo.queue_row_ids` order; do not rely on SQL output order.

## Finance formulas

The task memo's definition is controlling. Normally:

```text
total_cost          = variable_cost + fixed_cost_allocated
margin              = net_revenue - total_cost
revenue_to_cost     = net_revenue / total_cost
gap_to_120_percent  = (1.20 * total_cost) - net_revenue
```

Use integer cents for dollar addition/subtraction and a decimal arithmetic library or equivalent fixed-precision calculation for division and 1.2 multiplication.

- Add costs before rounding an output dollar: `total_cost_cents = variable_cents + fixed_cents`.
- Round `total_cost` and `margin` to two decimal places only at output.
- Compute the threshold decision from the unrounded ratio. Do not compare a ratio already rounded to four places.
- Output `revenue_to_cost_ratio` rounded to four decimal places.
- Treat `below_threshold = true` only when `revenue_to_cost_ratio < 1.20`; equality is not below threshold.
- Calculate the gap from the same unrounded row values, then round cents. A below-threshold gap should be nonnegative at the financial precision used; if it is negative, recheck the threshold logic and cost inputs.

Never divide by an absent or zero total cost. Such a row is an unresolved data exception, not an infinite ratio.

## Row action precedence

Apply threshold before charge sensitivity:

1. `below_threshold = true` -> `recommended_action = "payer_contract_review"` even if the row is also charge sensitive.
2. Otherwise, `charge_sensitive = true` -> `recommended_action = "monitor_charge_sensitive"`.
3. Otherwise -> `recommended_action = "monitor_no_action"`.

`charge_sensitive` remains the stored boolean in every row and is not suppressed by a below-threshold result.

## Aggregate segment lists and top issue

- `below_threshold_segments`: unique `payer_segment` values from rows with `below_threshold = true`, alphabetical by enum value.
- `charge_sensitive_segments`: unique `payer_segment` values from rows with stored charge sensitivity, alphabetical by enum value.
- `threshold_revenue_to_cost_ratio`: the memo threshold as a JSON number (`1.2`; template precision is four places).

Select `top_issue` from a below-threshold row whose segment/CPT combination maps to an allowed template value (`medicaid_97110`, `commercial_97530`, or `workers_comp_97112`). Use the most severe below-threshold row by lowest unrounded revenue-to-cost ratio. If ratios tie, choose the larger absolute dollar gap to 120 percent; if still tied, choose the earlier memo row. If no row is below threshold, use `none`.

The allowed `top_issue` enum may not cover every segment/CPT pair, but the supplied queue is expected to map. Do not rename a CPT or segment to force a mapping. If the most severe row cannot map and no business tie-break is supplied, expose the mismatch as unresolved instead of inventing an allowed value.

Set `gap_to_120pct` from that same selected top row, in dollars rounded to cents. Use `0` (rendering as `0.00` as needed) when `top_issue = "none"`.

## Audit construction

Set `basis_audit.source_precedence = "margin_threshold_then_charge_sensitivity"`.

- `controlling_record_ids`: the exact memo-listed `month_id`s in memo order, because each row directly controls a row output and the aggregate.
- `exception_record_ids`: only a listed row that has a genuine unresolved data anomaly; otherwise `[]`. Never add unlisted rows or global peer rows.
- `precedence_record_order`: copy the controlling order, then any exception IDs. Keep exact IDs.

## Final schema and consistency audit

Required keys are `case_id, period, threshold_revenue_to_cost_ratio, rows, below_threshold_segments, charge_sensitive_segments, top_issue, gap_to_120pct, basis_audit`. Every row requires `month_id, payer_segment, service_domain, cpt_code, total_cost, margin, revenue_to_cost_ratio, below_threshold, charge_sensitive, recommended_action`.

Verify independently:

1. `rows` is in exact memo order and contains no extra row.
2. Each `total_cost` equals its two cost components to the cent.
3. Each `margin = net_revenue - total_cost` to the cent.
4. Each output ratio is the rounded rendering of its unrounded revenue/cost quotient.
5. Each threshold boolean agrees with the unrounded ratio, and each action follows threshold-before-charge-sensitivity.
6. Both segment lists are unique, exact enums, and alphabetical.
7. `top_issue` and `gap_to_120pct` refer to the same top below-threshold row; recompute the 1.2 x cost gap once more.
8. `basis_audit` contains exactly the listed row IDs in memo order and no extraneous finance rows.
