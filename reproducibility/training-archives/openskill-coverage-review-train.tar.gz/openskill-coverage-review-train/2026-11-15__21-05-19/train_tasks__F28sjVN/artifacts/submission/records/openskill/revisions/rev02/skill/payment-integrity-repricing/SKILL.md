---
name: payment-integrity-repricing
description: Reprice a Northstar claim against the current effective payer/plan/CPT/modifier benchmark, calculate exact claim-line corrections, and select the operational correction route.
---

# Payment Integrity Repricing

## Applicability

Use when a paid or processed claim must be checked against a rate schedule and returned as a structured line-level correction packet. This Skill does not decide medical necessity except where a stored line denial or case criterion explicitly controls payability.

Required source precedence: `effective_benchmark_by_plan_modifier_and_date`.

## Evidence acquisition

Read `../references/data-map.md`, then:

1. Query the task-named claim. Resolve its member, case, payer, status, auth, billed total, paid total, and received date.
2. Query the member and reachable plan. Capture `plan_type`; the case service domain also identifies the benchmark domain.
3. Query every target claim line, ordered by `line_number` then `claim_line_id`. Never omit or regroup a line: preserve each line ID, CPT, modifier, units, paid amount, denial code, and service date.
4. Gather target case, request line, policy/criteria, and authorization only as needed to establish payability, service domain, scope, or the auth number. Do not substitute policy evidence for an effective rate.
5. For each line, derive the exact benchmark join key: claim payer, member/plan type, service domain, CPT, modifier (`NULL` remains `NULL`), and service date. Query all date-effective benchmark candidates for that key. Use the current effective schedule, not the nearest or newest-looking row.

If no applicable current benchmark exists for a covered line, leave it unresolved or denied as the template permits; never manufacture a rate from another plan, payer, CPT, modifier, or period.

## Benchmark selection

A candidate is usable only when:

- payer, plan type, service domain, CPT, and normalized modifier all equal the target values;
- `effective_start <= service_date <= effective_end`;
- the candidate is current for the reporting/as-of date and not retired, stale, or explicitly superseded; and
- its `source_name` and `source_version` identify a schedule permitted by the task.

Normalize an empty/blank modifier to JSON `null` for output. In SQL, do not use `modifier = ?` alone because it excludes nulls; use the explicit null-safe predicate in the data map.

If multiple candidate rows survive every equality/date test, do not pick arbitrarily. Use an explicit schedule-precedence or current-version rule in the target records. If the records remain ambiguous, report the ambiguity rather than selecting by highest ID.

The rejected source is the source tied to the target key/date that is stale, legacy, or not applicable. Do not label an unrelated distractor schedule as rejected merely to fill the field unless the target records show it was a competing source. Choose the exact enum value required by the template.

## Exact repricing arithmetic

Use integer cents internally.

1. Convert each benchmark `allowed_amount` to cents: `unit_allowed_cents = round_half_up(allowed_amount * 100)`.
2. Convert each stored paid amount to cents. Preserve the stored cents exactly; do not re-round a value already stated at two decimals.
3. For a payable line: `correct_allowed_cents = units * unit_allowed_cents`.
4. For a line whose stored denial/payability rule remains controlling: `correct_allowed_cents = 0` and disposition `deny_line`, unless an explicit correction rule says the denial is being overturned.
5. Line recovery is the signed difference `paid_cents - correct_allowed_cents`:
   - positive means overpayment to recover;
   - negative means an underpayment (the correction is upward); preserve the negative sign unless the supplied template explicitly requests an absolute underpayment amount.
6. Set `correct_allowed_total = sum(all correct_allowed_cents) / 100` and `paid_total` from the claim header, after checking it equals the sum of line paid cents. If header and line sums differ, record the discrepancy and follow the task's stated controlling total; never silently change the header.
7. Set `recovery_amount = paid_total - correct_allowed_total` using the same cents convention. Verify it also equals the sum of line recovery amounts.
8. Emit JSON numbers in dollars rounded to two decimal places. Avoid floating-point accumulation on already-rounded intermediate dollars; add cents, then divide once.

Per line, `correct_allowed_amount` is units times the per-unit allowed amount, not just the schedule's unit rate. `paid_amount` is the stored line paid amount, not the billed amount.

## Disposition and route

For each payable line:

- `correct_allowed_cents > paid_cents`: `correct_upward`.
- `correct_allowed_cents < paid_cents`: `correct_downward`.
- equal cents: `no_change`.
- controlling denial/unpayable line: `deny_line`.

Sort output lines by source claim-line order. Use the claim-line identifier in `line_id`, exact CPT/modifier, and integer units.

Select the route from explicit task/case evidence. For a repriced paid claim, the normal operational route is `payment_integrity_correction`. Use `no_resubmission` when every line is `no_change`; use a provider/appeal route only when the target record explicitly calls for it.

Select priority from an explicit urgency rule or stored task instruction. Do not invent a monetary threshold. If no expedite criterion is supplied, use `standard`; use `monitor_only` only when no correction is needed and the task asks to monitor.

## Audit construction

Set `basis_audit.source_precedence = "effective_benchmark_by_plan_modifier_and_date"`.

- `controlling_record_ids`: claim, ordered target claim lines, member/plan or case domain evidence, the selected effective benchmark rows, and authorization/scope records actually used.
- `exception_record_ids`: line payability or no-rate gaps first, then rejected stale/not-applicable benchmark rows. Include the relevant benchmark/source record ID because it explains the exclusion.
- `precedence_record_order`: controlling IDs in claim-line/benchmark operational order, followed by exceptions.

Every audit ID occurs once. Claim and case IDs can be the same business value across `claims` and `cases`; emit that value once as the controlling claim/case anchor rather than twice. A benchmark row has one role: controlling when selected, or exception when rejected. A line with a payability gap belongs in the exception array only if its decisive audit role is the gap; do not also repeat it as a controlling line. `precedence_record_order` must be the unique controls followed by unique exceptions.

## Final schema and consistency audit

Required keys are `claim_id, case_id, auth_number, benchmark_source, benchmark_version, stale_source_rejected, paid_total, correct_allowed_total, recovery_amount, lines, resubmission_route, priority, basis_audit`. Each line requires `line_id, cpt_code, modifier, units, paid_amount, correct_allowed_amount, recovery_amount, disposition`.

Perform all of these checks:

- claim/case/auth correspond to the target and the selected source/version are exact stored strings;
- lines are in source order and one-to-one with the claim lines (unless a line is explicitly aggregated by the task);
- every modifier is a string or JSON `null`, never `""`;
- line allowed arithmetic reproduces units x allowed rate;
- line paid/recovery totals reconcile to header/total fields to the cent;
- every disposition follows the sign of the arithmetic;
- benchmark source is date-effective for every service date relying on it;
- route/priority use exact allowed enum spelling and are supported by the target;
- all currency fields contain two-decimal JSON numbers, each audit array is unique, the arrays are disjoint, and `precedence_record_order` is exactly controlling followed by exceptions.
