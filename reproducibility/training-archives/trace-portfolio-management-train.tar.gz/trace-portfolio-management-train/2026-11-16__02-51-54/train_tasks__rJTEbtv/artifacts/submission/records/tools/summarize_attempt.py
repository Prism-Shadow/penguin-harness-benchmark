#!/usr/bin/env python3
import json, re, sys
from pathlib import Path

record = Path(sys.argv[1])
summary = {'record': str(record)}
if (record / 'result.json').is_file():
    summary['result'] = json.loads((record / 'result.json').read_text())
if (record / 'selected_skills.json').is_file():
    summary['selected_skills'] = json.loads((record / 'selected_skills.json').read_text())
if (record / 'answer.json').is_file():
    try:
        answer = json.loads((record / 'answer.json').read_text())
        summary['answer_top_keys'] = list(answer) if isinstance(answer, dict) else type(answer).__name__
    except Exception as exc:
        summary['answer_error'] = str(exc)
commands, endpoints, failed = [], set(), []
usage = {'input_tokens': 0, 'cached_input_tokens': 0, 'output_tokens': 0, 'reasoning_output_tokens': 0}
agent_messages = []
events_path = record / 'events.jsonl'
if events_path.is_file():
    for line in events_path.read_text(errors='replace').splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('type') == 'turn.completed':
            u = event.get('usage', {})
            for key in usage:
                usage[key] += int(u.get(key) or 0)
        item = event.get('item', {})
        if event.get('type') == 'item.completed' and item.get('type') == 'command_execution':
            command = str(item.get('command', ''))
            commands.append(command)
            endpoints.update(re.findall(r'http://127\.0\.0\.1:9010/[^\s\'\"]*', command))
            if item.get('exit_code') not in (0, None):
                failed.append({'exit_code': item.get('exit_code'), 'command': command[:500]})
        elif event.get('type') == 'item.completed' and item.get('type') == 'agent_message':
            text = str(item.get('text', ''))
            if text:
                agent_messages.append(text)
summary['usage'] = usage
summary['command_count'] = len(commands)
summary['endpoints'] = sorted(endpoints)
summary['failed_commands'] = failed
summary['last_agent_messages'] = agent_messages[-3:]
print(json.dumps(summary, indent=2, ensure_ascii=False))
