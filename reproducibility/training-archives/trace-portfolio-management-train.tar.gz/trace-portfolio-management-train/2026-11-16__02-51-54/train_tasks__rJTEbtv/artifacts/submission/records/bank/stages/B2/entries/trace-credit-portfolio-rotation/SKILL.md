---
name: trace-credit-portfolio-rotation
description: Use for bond trade-package, rotation, post-trade metric, watchlist, HY-cap, duration-band, issuer-concentration, or subsector-diversification decisions.
version: 2026.11.15.2
---

# Credit package and rotation selection

## Applicability
Use when a task asks for bond buys, sells, or a rotation together with post-trade risk metrics and policy pass flags.

## Inputs and prerequisites
Obtain current holdings, the bond security master, issuer watchlist, market signals, the task's candidate shortlist, and the applicable constrained policy. Require instrument, issuer, rating bucket, modified duration, yield to maturity, spread, subsector, theme tags, candidate flag, and live quantity.

## Procedure
1. Join holdings to the security master by instrument identifier and verify every held and candidate bond resolves. Translate the assignment into action type, ticket count, total size, candidate eligibility, and requested risk relief.
2. Build the post-trade position vector for each candidate decision. Reject negative holdings, duplicate tickets, trades above available quantity, and tickets that violate ticket-count or equal-size rules.
3. Recompute market value, high-yield share, market-value-weighted modified duration, and weighted yield from full-precision inputs. Check HY cap, duration band, issuer exposure, selected-issuer and selected-subsector diversification, and watchlist avoidance.
4. For a fixed buy-only package, enumerate feasible pairs across all three postures: investment-grade only, high-yield only, and blended. For each pair record theme alignment, carry uplift versus the current portfolio, HY headroom, issuer and subsector diversity, and post-trade duration.
5. Interpret "improve carry" as a risk-adjusted improvement, not permission to sort solely by absolute post-trade yield. Prefer a pair that includes a visible theme anchor tied to the strongest positive market signal and retains HY headroom over a pair that merely saturates the HY cap. A mixed pair can be preferable when it combines theme-supported quality with an income leg from a different issuer and subsector.
6. Choose the sales positioning theme from the strongest positive market signal and the selected bonds' theme tags. Choose the target segment from the client context; do not label a transition package as an LNG-income package or vice versa.
7. For a risk rotation, identify current watchlisted positions first and sell the full current live quantity; never substitute a stale memo quantity. Classify the remaining HY positions by carry, duration, and subsector.
8. If the policy still requires additional HY reduction, sell whole non-watchlist HY positions in ascending carry order first, one position at a time, stopping as soon as the post-trade HY share is at or below the cap and the required reduction is met while duration remains feasible. Retaining a higher-carry HY position is preferable to discarding it merely to liquidate the asset class. Use partial reductions only when whole-position choices cannot satisfy the constraints or the task explicitly requests them.
9. Fund the full sale proceeds into eligible, non-watchlisted shortlist candidates. Prefer a compact set of complementary legs that preserves a positive theme anchor and supplies duration or quality, while satisfying every explicit selected-issuer, subsector, and ticket constraint. If an issuer limit binds an equal two-leg allocation, add the minimum number of extra eligible issuers needed rather than exceeding the limit, leaving material proceeds idle, or concentrating the package in one leg. If no issuer constraint binds, a two-leg rotation is the default compact form.
10. Recompute every reported metric and flag from the final trade list, then round only for output.
11. Set the risk note from the final package's principal trade-off, not merely from the pre-trade breach. Use `carry_tradeoff` when risk reduction intentionally sells income-producing HY exposure and reinvests at lower yield, even when a cap initially motivated the rotation. Use `watchlist_concentration` for a watchlist-only remediation, `duration_preservation` when duration fit is the binding concern, `hy_cap_pressure` when the residual package remains cap-constrained, and `no_action` only when no trade is proposed.

## Checks
- Current holdings, not memo exception quantities, drive sells.
- The package meets the HY cap and required reduction without unnecessary liquidation.
- Full proceeds are funded into eligible candidates unless the task explicitly permits cash.
- Selected issuers and subsectors are diverse under the policy.
- No new watchlist exposure is added.
- Sales theme and target segment agree with the selected bonds and strongest market signal.
- The risk note describes the final package's main trade-off.
- A full liquidation is a distinct strategy, not a default interpretation of "reduce".

## Failure avoidance
Do not equate highest post-trade YTM with the best income package. Do not use tiny partial sells when whole-position sales can meet the risk target. Do not add unnecessary funding legs, but do not violate a selected-issuer limit to keep the ticket count artificially low. Do not optimize one metric while leaving the theme, duration, diversification, or risk-note rationale unsupported.
